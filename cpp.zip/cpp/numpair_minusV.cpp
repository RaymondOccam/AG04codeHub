#include <iostream>
#include <map>
#define ll long long
using namespace std;
ll n, c;
ll a[5000000];
ll res;
map<ll, ll> m;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> c;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i];
        m[a[i] + c]++;
    }
    for (ll i = 0; i < n; i++)
    {
        res += m[a[i]];
    }
    cout << res;
    return 0;
}