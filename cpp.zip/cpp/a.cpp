#include <iostream>
#pragma GCC optimize("Ofast", "inline", "-ffast-math")
#pragma GCC target("avx,sse2,sse3,sse4,mmx")
#define ll long long
#define MAXN 1000010ll
using namespace std;
ll n, x;
struct Node
{
    ll bg;
    ll ed;
} a[MAXN], maxn, minn;
ll maxx(ll a, ll b)
{
    return b & ((a - b) >> 31) | a & (~(a - b) >> 31);
}
ll minx(ll a, ll b)
{
    return a & ((a - b) >> 31) | b & (~(a - b) >> 31);
}
ll maxnum, minnum;
ll ans;
bool inside(ll a, ll m, ll b)
{
    return (m >= minx(a, b) && m <= maxx(a, b)) ? true : false;
}
bool flg = false;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> x;
    for (ll i(0); i < n; i++)
    {
        cin >> a[i].bg >> a[i].ed;
        maxn.bg = maxx(maxn.bg, a[i].bg);
        maxn.ed = maxx(maxn.ed, a[i].ed);
        maxnum = maxx(maxn.bg, maxn.ed);
        minn.bg = minx(minn.bg, a[i].bg);
        minn.ed = minx(minn.ed, a[i].ed);
        minnum = minx(minn.bg, minn.ed);
    }
    for (ll i(minnum); i <= maxnum; i++)
    {
        for (ll j(0); j < n; j++)
        {
            if (inside(a[j].bg, i, a[j].ed) == false)
            {
                goto out;
            }
        }
        ans = minx(ans, abs(x - i));
        flg = true;
    out:
    {
        break;
    }
    }
    if (flg == false)
    {
        cout << -1;
        return 0;
    }
    cout << ans;
    return 0;
}