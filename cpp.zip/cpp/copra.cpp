#include <bits/stdc++.h>
#define ll long long
using namespace std;
double c, res;
char a[1000], b[1000];
ll len;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> c >> a >> b;
    len = strlen(a);
    for (ll i = 0; i < len; i++)
    {
        if (a[i] == b[i])
        {
            res++;
        }
    }
    res /= len;
    if (res >= c)
    {
        cout << "yes" << '\n';
    }
    else
    {
        cout << "no" << '\n';
    }
    return 0;
}