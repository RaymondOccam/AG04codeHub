#include <iostream>
#include <algorithm>
#include <queue>
#define ll long long
#define MAXN 10050
using namespace std;
struct Node
{
    ll x;
    friend bool operator<(Node p, Node q)
    {
        return p.x > q.x;
    }
} g;
ll n, m;
ll temp[MAXN];
ll a[MAXN], b[MAXN], c[MAXN];
ll pos, x;
priority_queue<Node> pq;
ll func(ll ap, ll bp, ll cp, ll x)
{
    return ap * x * x + bp * x + cp;
}
bool flag;
ll t;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i] >> b[i] >> c[i];
    }
    while (1)
    {
        x++;
        for (ll i = 0; i < n; i++)
        {
            if (m - pos < n)
            {
                flag = true;
                break;
            }
            pos++;
            g.x = func(a[i], b[i], c[i], x);
            pq.push(g);
            // cout << "g.x:" << g.x << '\n';
        }
        if (flag == true)
        {
            break;
        }
    }
    t = m - pos;
    // for (ll i = 0; i < n; i++)
    // {
    //     if (t + i == n && x * n <= m)
    //     {
    //         x++;
    //     }
    //     temp[i] = func(a[i], b[i], c[i], x);
    //     // cout << "temp[i]:" << temp[i] << '\n';
    // }

    for (ll i = t; i < n; i++)
    {
        temp[i] = func(a[i], b[i], c[i], x);
    }
    x++;
    for (ll i = 0; i < t; i++)
    {
        temp[i] = func(a[i], b[i], c[i], x);
    }
    cout << "t:\n";
    for (ll i = 0; i < n; i++)
    {
        cout << temp[i] << ' ';
    }
    cout << "\n\\t";
    sort(temp, temp + n);
    for (ll i = 0; i < t; i++)
    {
        g.x = temp[i];
        pq.push(g);
    }
    while (m--)
    {
        cout << pq.top().x << ' ';
        pq.pop();
    }
    return 0;
}