#include <iostream>
#include <algorithm>
#include <string>
#include <set>
#define ll long long
using namespace std;
int n;
struct Stud
{
    string nm;
    int che;
    int mth;
    ll id = 1;
    bool flag = true;
    // id_max = n_max * n_max = 5e4 * 5e4 = 2.5e9
    // int_max �� 2.1e9�����Կ�long long
} cls[50000], yes[50000];
bool cmp1(Stud a, Stud b)
{
    return a.che > b.che;
}
bool cmp2(Stud a, Stud b)
{
    return a.mth > b.mth;
}
bool cmp3(Stud a, Stud b)
{
    return a.id < b.id;
}
int chihg;
int mthhg;
bool is_output = false;
// class temp
// {
// public:
//     bool operator()(const int a, const int b)
//     {
//         return a > b;
//     }
// };
int main()
{
    set<int> cschi;
    set<int> csmth;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> cls[i].nm >> cls[i].che >> cls[i].mth;
        cschi.insert(cls[i].che);
        csmth.insert(cls[i].mth);
    }
    int pos = 0;
    auto it = cschi.end();
    // 1 2 3
    for (int i = 1; i <= cschi.size() / 2; i++)
    {
        it--;
    }
    chihg = *it;
    it = csmth.end();
    for (int i = 1; i <= csmth.size() / 2; i++)
    {
        it--;
    }
    mthhg = *it;
    for (int i = 0; i < n; i++)
    {
        if (cls[i].mth >= mthhg && cls[i].che >= chihg)
        {
            yes[pos] = cls[i];
            pos++;
        }
    }
    sort(yes, yes + pos, cmp1);
    for (ll i = 1; i <= pos; i++)
    {
        yes[i - 1].id *= i;
    }
    sort(yes, yes + pos, cmp2);
    for (ll i = 1; i <= pos; i++)
    {
        yes[i - 1].id *= i;
    }
    sort(yes, yes + pos, cmp3);
    for (ll i = 0; i < pos; i++)
    {
        cout << yes[i].nm << endl;
        is_output = true;
    }
    if (!is_output)
    {
        cout << "none";
    }
    return 0;
}