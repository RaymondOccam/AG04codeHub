#include <iostream>
#include <vector>
#define ll long long
using namespace std;
int main()
{
    
    return 0;
}