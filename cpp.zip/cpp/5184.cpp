#include <iostream>
#include <map>
#define ll long long
#define MAXN 100070
using namespace std;
ll n, m;
ll a[MAXN];
ll sum[MAXN];
ll l, r;
ll sur;
ll cr;
bool flg;
map<ll, ll> now;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 1; i <= n; i++)
    {
        cin >> a[i];
        now[a[i]]++;
    }
    sur = now.size();
    cr = 1;
    while (m--)
    {
        cr = l;
        flg = 0;
        cin >> l;
        for (ll i = cr; i <= l; i++)
        {
            now[a[i]]--;
            if (now[a[i]] == 0)
            {
                sur--;
                flg = 1;
            }
        }
        if (flg == 1)
        {
            cout << sur + 1;
        }
        else
        {
            cout << sur;
        }
        cout << '\n';
    }
    return 0;
}