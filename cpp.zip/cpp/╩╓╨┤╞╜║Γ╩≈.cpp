#include <iostream>
#include <vector>
#define ll long long
using namespace std;
class AVLTree
{
private:
    struct Node
    {
        ll key, height;
        Node *left, *right;
        Node(ll key) : key(key), height(1), left(nullptr), right(nullptr) {}
    };
    Node *root;
    ll height(Node *node)
    {
        return node ? node->height : 0;
    }
    ll max(ll a, ll b)
    {
        return a > b ? a : b;
    }
    Node *updateHeight(Node *node)
    {
        if (!node)
        {
            return nullptr;
        }
        node->height = 1 + max(height(node->left), height(node->right));
        return node;
    }
    ll getBalance(Node *node)
    {
        return node ? height(node->left) - height(node->right) : 0;
    }
    Node *leftRotate(Node *x)
    {
        Node *y = x->right;
        x->right = y->left;
        y->left = x;
        x = updateHeight(x);
        y = updateHeight(y);
        return y;
    }
    Node *rightRotate(Node *y)
    {
        Node *x = y->left;
        y->left = x->right;
        x->right = y;
        y = updateHeight(y);
        x = updateHeight(x);
        return x;
    }
    Node *balance(Node *node)
    {
        if (!node)
        {
            return nullptr;
        }
        ll balance = getBalance(node);
        if (balance > 1)
        {
            ll childBalance = getBalance(node->left);
            if (childBalance == 1)
            {
                node->left = leftRotate(node->left);
            }
            return rightRotate(node);
        }
        if (balance < -1)
        {
            ll childBalance = getBalance(node->right);
            if (childBalance == -1)
            {
                node->right = rightRotate(node->right);
            }
            return leftRotate(node);
        }
        return node;
    }
    Node *insert(Node *node, ll key)
    {
        if (!node)
        {
            return new Node(key);
        }
        if (key < node->key)
        {
            node->left = insert(node->left, key);
        }
        else if (key > node->key)
        {
            node->right = insert(node->right, key);
        }
        else
        {
            return node;
        }
        node = updateHeight(node);
        return balance(node);
    }
    void preOrder(Node *node)
    {
        if (node)
        {
            cout << node->key << " ";
            preOrder(node->left);
            preOrder(node->right);
        }
    }

public:
    AVLTree() : root(nullptr) {}
    void insert(ll key)
    {
        root = insert(root, key);
    }
    void preOrder()
    {
        preOrder(root);
    }
};
int main()
{
    
    return 0;
}