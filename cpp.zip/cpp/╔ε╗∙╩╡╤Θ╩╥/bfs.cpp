#include <iostream>
#include <string.h>
#include <iomanip>
#include <queue>
#define ll long long
#define MAXN 405
using namespace std;
queue<ll> qx, qy;
ll a[MAXN][MAXN], ans[MAXN][MAXN], n, m, sx, sy;
ll dx[] = {-2, -2, 2, 2, 1, -1, 1, -1};
ll dy[] = {-1, 1, -1, 1, 2, -2, -2, 2};
int main()
{
    memset(ans, -1, sizeof(ans));
    cin >> n >> m >> sx >> sy;
    qx.push(sx);
    qy.push(sy);
    ans[sx][sy] = 0;
    a[sx][sy] = 1;
    while (!qx.empty())
    {
        for (ll i = 0; i < 8; i++)
        {
            ll tx = qx.front() + dx[i];
            ll ty = qy.front() + dy[i];
            if (tx > 0 && tx <= n && ty > 0 && ty <= m && a[tx][ty] == 0)
            {
                a[tx][ty] = 1;
                ans[tx][ty] = ans[qx.front()][qy.front()] + 1;
                qx.push(tx);
                qy.push(ty);
            }
        }
        qx.pop();
        qy.pop();
    }
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = 1; j <= m; j++)
        {
            cout << ans[i][j] << setw(5) << "";
        }
        puts("");
    }
    return 0;
}