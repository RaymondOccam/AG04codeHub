#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
vector<ll> v(100000);
ll fun(ll n)
{
    for (ll i = 2; i * i <= n; i++)
    {
        if (n % i == 0)
        {
            return i;
        }
    }
    return n;
}
ll ans;
int main()
{
    cin >> n;
    for (ll i = 2; i <= n; i++)
    {
        ans = fun(i);
        v[ans]++;
    }
    for (ll i = 2; i <= n; i++)
    {
        cout << v[i] << endl;
    }
    return 0;
}