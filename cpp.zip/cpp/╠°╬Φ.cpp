#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n, m;
ll cnt;
vector<pair<ll, bool> > boy;
vector<pair<ll, bool> > girl;
vector<pair<ll, ll> > ans;
int main()
{
    cin >> n >> m;
    boy.resize(n + 1);
    girl.resize(m + 1);
    ans.resize(n * m + 1);
    for (ll i = 0; i < n; i++)
    {
        boy[i].first = i + 1;
        boy[i].second = false;
    }
    for (ll i = 0; i < m; i++)
    {
        girl[i].first = i + 1;
        girl[i].second = false;
    }
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            if (boy[i].second == false || girl[j].second == false)
            {
                boy[i].second = true;
                girl[j].second = true;
                ans[cnt].first = boy[i].first;
                ans[cnt].second = girl[j].first;
                cnt++;
            }
        }
    }
    cout << cnt << endl;
    for (ll i = 0; i < cnt; i++)
    {
        cout << ans[i].first << ' ' << ans[i].second << endl;
    }
    return 0;
}