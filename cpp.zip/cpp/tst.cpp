#include <iostream>
#include <vector>
#define ll long long
using namespace std;
int main()
{
    vector<ll> a(10);
    a[0] = 1;
    a[1] = 2;
    a.erase(a.begin(), a.begin() + 1);
    cout << a[0];
    return 0;
}