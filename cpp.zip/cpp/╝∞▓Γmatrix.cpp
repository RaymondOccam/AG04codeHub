#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
ll cnt1, cnt2;
ll sum1, sum2;
ll row;
ll col;
ll h[10000];
ll l[10000];
int main()
{
    cin >> n;
    vector<vector<ll>> matrix(n, vector<ll>(n));
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < n; j++)
        {
            cin >> matrix[i][j];
        }
    }
    for (ll i = 0; i < n; i++)
    {
        cnt1 = 0;
        cnt2 = 0;
        for (ll j = 0; j < n; j++)
        {
            cnt1 += matrix[i][j];
            cnt2 += matrix[j][i];
        }
        h[i] = cnt1;
        l[i] = cnt2;
    }
    for (ll i = 0; i < n; i++)
    {
        if (h[i] % 2 != 0)
        {
            sum1++;
            row = i + 1;
        }
        if (l[i] % 2 == 1)
        {
            sum2++;
            col = i + 1;
        }
    }
    if (sum1 + sum2 == 0)
    {
        cout << "OK";
    }
    else if (sum1 == 1 && sum2 == 1)
    {
        cout << row << ' ' << col;
    }
    else
    {
        cout << "Corrupt";
    }
    return 0;
}