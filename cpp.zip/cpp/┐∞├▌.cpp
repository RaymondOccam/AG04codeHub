#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll qpow(ll a, ll b)
{
    ll sum = 1;
    ll m = LLONG_MAX;
    while (b)
    {
        if (b & 1)
        {
            sum = sum * a % m;
        }
        a = a * a % m;
        b >>= 1;
    }
    return sum;
}
int main()
{
    
    return 0;
}