#include <iostream>
#define ll long long
using namespace std;
ll n;
ll a, b, c, d, e, f;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    a = n / 100;
    n %= 100;
    b = n / 50;
    n %= 50;
    c = n / 20;
    n %= 20;
    d = n / 10;
    n %= 10;
    e = n / 5;
    n %= 5;
    f = n;
    n = 0;
    cout << a << ' ' << b << ' ' << c << ' ' << d << ' ' << e << ' ' << f;
    return 0;
}