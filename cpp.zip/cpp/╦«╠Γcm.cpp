#include <iostream>
#define ll long long
using namespace std;
int main()
{
    ll a, b;
    cin >> a >> b;
    cout << b;
    return 0;
}