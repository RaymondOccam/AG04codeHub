#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;
double a[520], sum, minn = 99999999, maxn = -1, maxi, mini, maxd = -1;
int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        minn = min(minn, a[i]);
        if (a[i] == minn)
        {
            mini = i;
        }
        maxn = max(maxn, a[i]);
        if (a[i] == maxn)
        {
            maxi = i;
        }
        sum += a[i];
    }
    sum -= minn + maxn;
    printf("%.2lf ", sum / (n - 2));
    for (int i = 1; i <= n; i++)
    {
        if (i != mini && i != maxi)
        {
            maxd = max(maxd, fabs(a[i] - sum / (n - 2)));
        }
    }
    printf("%.2lf", maxd);
    return 0;
}