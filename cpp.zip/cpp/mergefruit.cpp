#include <iostream>
#include <queue>
#define ll long long
using namespace std;
ll res;
struct Node
{
    ll x;
    friend bool operator<(Node a, Node b)
    {
        return a.x > b.x;
    }
};
ll n, x;
priority_queue<Node> pq, qp;
ll u, v;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    while (n--)
    {
        cin >> x;
        pq.push({x});
    }
    while (pq.size() > 1)
    {
        u = pq.top().x;
        pq.pop();
        v = pq.top().x;
        pq.pop();
        res += u + v;
        pq.push({u + v});
    }
    cout << res;
    return 0;
}