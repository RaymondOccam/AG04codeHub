#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
vector<ll> v;
ll maxn = LLONG_MIN;
ll cnt = 1;
ll tower = 1;
bool flag = false;
int main()
{
    cin >> n;
    v.resize(n);
    for (ll i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    sort(v.begin(), v.end());
    for (ll i = 0; i < n - 1; i++)
    {
        if (v[i] == v[i + 1])
        {
            cnt++;
        }
        else
        {
            tower++;
            cnt = 1;
            flag = true;
        }
        maxn = max(maxn, cnt);
    }
    if (flag == false)
    {
        cout << n << ' ' << tower;
        return 0;
    }
    cout << maxn << ' ' << tower;
    return 0;
}