#include <iostream>
#include <vector>
#include <map>
#include <queue>
#define ll long long
#define MAXN 10090
using namespace std;
struct Node
{
    ll x, y;
    friend bool operator<(Node a, Node b)
    {
        return a.y < b.y;
    }
};
map<ll, ll> m;
ll l, p, n, x;
ll pos;
ll res;
ll a[MAXN], b[MAXN];
priority_queue<Node> pq;
map<ll, ll>::iterator it;
int main()
{
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    // cout.tie(0);
    cin >> l >> p >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> x >> m[x];
    }
    it = m.begin();
    while (1)
    {
        pos += p;
        p = 0;
        while (pos >= it->first && it != m.end())
        {
            pq.push({it->first, it->second});
            it++;
        }
        if (pos >= l)
        {
            break;
        }
        if (p == 0)
        {
            res++;
            if (pq.empty())
            {
                cout << -1;
                return 0;
            }
            p += pq.top().y;
            pq.pop();
        }
    }
    cout << res;
    return 0;
}