#include <iostream>
#include <vector>
#define ll long long
using namespace std;
void dfs(ll node, vector<vector<ll>> &graph, vector<bool> &visited)
{
    visited[node] = true;
    for (ll neighbor : graph[node])
    {
        if (!visited[neighbor])
        {
            dfs(neighbor, graph, visited);
        }
    }
}
ll countFoodChains(ll n, vector<vector<ll>> &graph)
{
    vector<bool> visited(n + 1, false);
    ll count = 0;
    for (ll i = 1; i <= n; i++)
    {
        if (!visited[i])
        {
            dfs(i, graph, visited);
            count++;
        }
    }
    return count;
}
ll foodChains, n, m, a, b;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    vector<vector<ll>> graph(n + 1);
    for (ll i = 0; i < m; i++)
    {
        
        cin >> a >> b;
        graph[a].push_back(b);
    }
    countFoodChains(n, graph);
    cout << foodChains << '\n';
    return 0;
}