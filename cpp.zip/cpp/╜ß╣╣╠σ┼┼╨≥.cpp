#include <bits/stdc++.h>
#define ll long long
#pragma warning(disable:4996)
using namespace std;
struct Computer
{
    string name;
    string brand;
    string model;
    ll memory;
}a[3];
bool cmp(Computer o, Computer p)
{
    return (o.memory >= p.memory ? 1 : 0);
}
int main()
{
    a[0].brand = "Apple";
    a[0].model = "Macbook Pro";
    a[0].name = "kkk";
    a[0].memory = 18;
    a[1].brand = "ThinkPad";
    a[1].model = "E14 Gen2";
    a[1].name = "DESKTOP-DSQBP41";
    a[1].memory = 16;
    a[2].brand = "Surface";
    a[2].model = "Pro 9";
    a[2].name = "DESKTOP-OIU12DP";
    a[2].memory = 32;
    sort(a, a + 3, cmp);
    for (ll i = 0; i < 3; i++)
    {
        cout << a[i].name << ' ' << a[i].brand << ' ' << a[i].model << ' ' << a[i].memory << endl;
        cout << "--------------------------------" << endl;
    }
    return 0;
}