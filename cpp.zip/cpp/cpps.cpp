#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll m, n;
int main()
{
    
    return 0;
}