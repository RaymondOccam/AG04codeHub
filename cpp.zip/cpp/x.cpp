#include <iostream>
#include <vector>
#include <algorithm>
#pragma GCC optimize("Ofast", "inline", "-ffast-math")
#pragma GCC target("avx,sse2,sse3,sse4,mmx")
#define ll long long
using namespace std;
ll n, x;
ll res;
pair<ll, ll> rd;
vector<pair<ll, ll> > alts;
inline bool cmp(const pair<ll, ll> a, const pair<ll, ll> b)
{
    return a.first < b.first;
}
inline bool inc(ll f, ll r, ll val)
{
    return val >= f && val <= r;
}
inline bool chase(ll f1, ll r1, ll f2, ll r2)
{
    if (r1 >= f2)
    {
        return true;
    }
    if (r2 >= f1)
    {
        return true;
    }
    if (r1 >= r2 && f1 <= f2)
    {
        return true;
    }
    if (r2 >= r2 && f2 >= f1)
    {
        return true;
    }
    return false;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> x;
    for (ll i = 0; i < n; i++)
    {
        cin >> rd.first >> rd.second;
        alts.push_back(rd);
    }
    return 0;
}