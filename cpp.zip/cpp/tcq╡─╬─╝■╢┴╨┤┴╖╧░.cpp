#include <bits/stdc++.h> 
#define ll long long
using namespace std;
string o, p;
string pls(string a, string b) // ��
{
    string ans;
    ll carry = 0;
    ll sum;
    ll len;
    ll lena = a.size();
    ll lenb = b.size();
    ans.clear();
    len = max(a.size(), b.size());
    reverse(a.begin(), a.end());
    reverse(b.begin(), b.end());
    for (ll i = 0; i < len; i++)
    {
        sum = carry;
        if (i < lena)
        {
            sum += a[i] - '0';
        }
        if (i < lenb)
        {
            sum += b[i] - '0';
        }
        ans += sum % 10 + '0';
        carry = sum / 10;
    }
    if (carry)
    {
        ans += '1';
    }
    while (ans.back() == '0' && ans.size() > 1)
    {
        ans.pop_back();
    }
    reverse(ans.begin(), ans.end());
    return ans;
}
string mns(string m1, string m2) // ��
{
    string answ;
    ll sum;
    bool le0 = false;
    answ.clear();
    if (m1.size() < m2.size() || (m1.size() == m2.size() && m1 < m2))
    {
        le0 = true;
        swap(m1, m2);
    }
    reverse(m1.begin(), m1.end());
    reverse(m2.begin(), m2.end());
    for (ll i = 0; m1[i]; i++)
    {
        sum = m1[i] - '0';
        if (i < m2.size())
        {
            sum -= m2[i] - '0';
        }
        if (sum < 0)
        {
            m1[i + 1]--;
            sum += 10;
        }
        answ += sum % 10 + '0';
    }
    while (answ.size() > 1 && answ.back() == '0')
    {
        answ.pop_back();
    }
    if (le0 == true)
    {
        answ += '-';
    }
    reverse(answ.begin(), answ.end());
    return answ;
}
string tms(string num1, string num2)
{
    int n1 = num1.size();
    int n2 = num2.size();
    if (n1 == 0 || n2 == 0)
    {
        return "0";
    }
    reverse(num1.begin(), num1.end());
    reverse(num2.begin(), num2.end());
    string result(n1 + n2, '0');
    for (int i = 0; i < n2; i++)
    {
        int carry = 0;
        int digit2 = num2[i] - '0';
        for (int j = 0; j < n1; j++)
        {
            int digit1 = num1[j] - '0';
            int product = digit1 * digit2 + carry + (result[i + j] - '0');
            result[i + j] = product % 10 + '0';
            carry = product / 10;
        }
        if (carry)
        {
            result[i + n1] = carry + '0';
        }
    }
    reverse(result.begin(), result.end());
    while (result[0] == '0' && result.size() > 1)
    {
        result.erase(0, 1);
    }
    return result;
}
string solve(ll n)
{
    string res = "1";
    for (ll i = 1; i <= n; i++)
    {
        res = tms(res, to_string(i));
    }
    return res;
}
int main()
{
    string res = "0";
    ll n;
    cin >> n;
    for (ll i = 1; i <= n; i++)
    {
        res = pls(res, solve(i));
    }
    cout << res;
    return 0;
}