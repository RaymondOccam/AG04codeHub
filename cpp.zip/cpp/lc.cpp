#include <iostream>
#include <string>
#include <algorithm>
#define ll long long
using namespace std;
ll n;
struct Stud
{
    string nm;
    ll c, cid;
    ll m, mid;
    ll id;//id = cid * mid
};
int main()
{
    cin >> n;
    while (n--)
    {
        
    }
    return 0;
}