#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll t;
ll a1, b1, c1;
ll a2, b2, c2;
ll ans;
int main()
{
    cin >> t;
    while (t--)
    {
        ans = 0;
        cin >> a1 >> a2;
        // 1���У�2����
        cin >> b1 >> b2;
        cin >> c1 >> c2;
        if (min(b1, c1) > a1)
        {
            ans += min(b1, c1) - a1;
        }
        if (max(b1, c1) < a1)
        {
            ans += a1 - max(b1, c1);
        }
        if (min(b2, c2) > a2)
        {
            ans += min(b2, c2) - a2;
        }
        if (max(b2, c2) < a2)
        {
            ans += a2 - max(b2, c2);
        }
        
        ans++;
        cout << ans << "\n";
    }
    return 0;
}