#include <iostream>
#define ll long long
using namespace std;
ll q;
ll n, m, k;
bool flg;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> q;
    while (q--)
    {
        flg = 0;
        cin >> n >> m >> k;
        for (ll i = 0; i <= n; i++)
        {
            for (ll j = 0; j <= m; j++)
            {
                if (i * m + j * n - 2 * i * j == k)
                {
                    flg = 1;
                    break;
                }
            }
            if (flg == 1)
            {
                cout << "Yes\n";
                break;
            }
        }
        if (flg == 0)
        {
            cout << "No\n";
        }
    }
    return 0;
}