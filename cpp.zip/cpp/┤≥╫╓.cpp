#include <iostream>
#define ll long long
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout << "31.41593\n";
    cout << "78.539825\n";
    cout << "523.59883333\n";;
    return 0;
}