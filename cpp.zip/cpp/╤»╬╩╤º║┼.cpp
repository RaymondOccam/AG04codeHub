#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n, m;
vector<ll> v;
ll num;
int main()
{
    cin >> n >> m;
    v.resize(n);
    for (ll i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    for (ll i = 0; i < m; i++)
    {
        cin >> num;
        cout << v[num - 1] << endl;
    }
    return 0;
}