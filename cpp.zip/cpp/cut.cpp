#include <bits/stdc++.h>
#define ll long long
using namespace std;
vector<ll> n;
int main()
{
    
    return 0;
}