#include <iostream>
#include <algorithm>
#include <string>
#define ll long long
using namespace std;
int n;
bool isf = true;
struct Stud
{
    string nm;
    int che;
    int mth;
    ll id = 1;
    bool flag = true;
    // id_max = n_max * n_max = 5e4 * 5e4 = 2.5e9
    // int_max �� 2.1e9�����Կ�long long
} cls[50000];
bool cmp1(Stud a, Stud b)
{
    return a.che > b.che;
}
bool cmp2(Stud a, Stud b)
{
    return a.mth > b.mth;
}
bool cmp3(Stud a, Stud b)
{
    return a.id < b.id;
}
int main()
{
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> cls[i].nm >> cls[i].che >> cls[i].mth;
    }
    sort(cls, cls + n, cmp1);
    for (int i = 0; i < n; i++)
    {
        cls[i].id *= i + 1;
        if (i >= n / 2)
        {
            cls[i].flag = false;
        }
    }
    sort(cls, cls + n, cmp2);
    for (int i = 0; i < n; i++)
    {
        cls[i].id *= i + 1;
        if (i >= n / 2)
        {
            cls[i].flag = false;
        }
    }
    sort(cls, cls + n, cmp3);
    for (int i = 0; i < n / 2; i++)
    {
        if (cls[i].flag == true)
        {
            cout << cls[i].nm << endl;
            isf = false;
        }
    }
    if (isf)
    {
        cout << "none";
    }
    return 0;
}