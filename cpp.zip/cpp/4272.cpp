#include <iostream>
#define ll long long
using namespace std;
ll n, p1, p2, p3, t1, t2;
ll res, dis, elc;
struct Time
{
    ll l, r;
} a[200];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> p1 >> p2 >> p3 >> t1 >> t2;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i].l >> a[i].r;
    }
    for (ll i = 0; i < n; i++)
    {
        res += (a[i].r - a[i].l) * p1;
        if (i >= 1)
        {
            dis = a[i].l - a[i - 1].r;
            if (dis > t1)
            {
                res += t1 * p1;
                dis -= t1;
                if (dis > t2)
                {
                    res += t2 * p2;
                    dis -= t2;
                    res += dis * p3;
                    dis = 0;
                }
                else
                {
                    elc = dis * p2;
                    res += elc;
                    dis = 0;
                }
            }
            else
            {
                elc = dis * p1;
                res += elc;
                dis = 0;
            }
        }
    }
    cout << res;
    return 0;
}