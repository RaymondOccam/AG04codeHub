#include <iostream>
#include <stack>
#define ll long long
using namespace std;
ll n, k;
ll res;
ll op;
ll lft;
stack<pair<ll, ll>> rol;
pair<ll, ll> rd;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    while (n--)
    {
        cin >> op;
        if (op == 1)
        {
            cin >> rd.first >> rd.second;
            rol.push(rd);
        }
        else
        {
            cin >> k;
            res = 0;
            // �����ȫ��
            while (k > (rol.top().second - rol.top().first + 1))
            {
                ll l = rol.top().first;
                ll r = rol.top().second;
                res += (l + r) * (r - l + 1) / 2; // Sn = (A0 + An) * n / 2
                k -= r - l + 1;
                rol.pop();
            }
            // ��ȫ��
            lft = rol.top().second - k + 1; // ��ʼȡֵ����˵�
            res += (lft + rol.top().second) * (rol.top().second - lft + 1) / 2;
            rol.top().second -= k; // �����Ҷ˵�
            cout << res << '\n';
        }
    }
    return 0;
}