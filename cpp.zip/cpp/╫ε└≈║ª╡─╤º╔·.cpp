#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
ll d, b, c;
struct Node
{
    string name;
    ll t;
    ll q, w, e;
} a[100000];
bool cmp(Node m, Node n)
{
    return m.t > n.t;
}
int main()
{
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i].name;
        cin >> d;
        a[i].t += d;
        a[i].q = d;
        cin >> b;
        a[i].t += b;
        a[i].w = b;
        cin >> c;
        a[i].t += c;
        a[i].e = c;
    }
    sort(a, a + n, cmp);
    cout << a[0].name << ' ' << a[0].q << ' ' << a[0].w << ' ' << a[0].e;
    return 0;
}