#include <iostream>
#include <stack>
#include <vector>
#define ll long long
using namespace std;
ll n;
ll rd;
stack<ll> a;
vector<ll> res;
bool flg = false;
int main()
{
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> rd;
        if (a.empty())
        {
            a.push(rd);
            continue;
        }
        while (rd > a.top())
        {
            a.pop();
            if (a.empty())
            {
                flg = true;
                break;
            }
        }
        if (flg == false)
        {
            a.push(rd);
        }
        flg = false;
    }
    for (ll i = 0; i < a.size(); i++)
    {
        res.push_back(a.top());
        a.pop();
    }
    for (ll i = res.size() - 1; i >= 0; i--)
    {
        cout << res[i] << '\n';
    }
    return 0;
}