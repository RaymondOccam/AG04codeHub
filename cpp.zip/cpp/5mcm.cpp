#include <iostream>
#define ll long long
using namespace std;
int main()
{
    // freopen("challenge.in", "r", stdin);
    // freopen("challenge.out", "w", stdout);
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    
    return 0;
}