#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll cnt;
int main()
{
    for (ll i = 0; ; i++)
    {
        cnt++;
    }
    return 0;
}