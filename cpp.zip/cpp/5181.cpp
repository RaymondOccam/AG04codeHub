#include <iostream>
#include <vector>
#define ll long long
#define MAXN 1050
using namespace std;
ll n, m, k;
ll sum[MAXN][MAXN];
ll tar;
ll a, h;
ll xa, ya, xb, yb;
ll res;
int main()
{
    cin >> n >> m >> k;
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = 1; j <= m; j++)
        {
            cin >> tar;
            sum[i][j] = sum[i - 1][j] + sum[i][j - 1] - sum[i - 1][j - 1] + tar;
        }
    }
    while (k--)
    {
        cin >> xa >> ya >> xb >> yb;
        res = sum[xb][yb] - sum[xb][ya - 1] - sum[xa - 1][yb] + sum[xa - 1][ya - 1]; 
        cout << res << '\n';
    }
    return 0;
}