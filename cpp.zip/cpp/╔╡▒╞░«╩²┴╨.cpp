#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n, k;
ll rd;
vector<ll> v;
char m;
int main()
{
    ll x, y;
    cin >> n >> k;
    for (ll i = 0; i < n; i++)
    {
        cin >> rd;
        v.push_back(rd);
    }
    for (ll i = 0; i < k; i++)
    {
        cin >> m;
        if (m == 'Z')
        {
            cin >> x >> y;
            if (x > v.size())
            {
                v.push_back(y);
            }
            else
            {
                v.insert(v.begin() + x, y);
            }
        }
        else if (m == 'D')
        {
            cin >> x;
            if (x >= v.size())
            {
                continue;
            }
            v.erase(v.begin() + x, v.begin() + x + 1);
        }
    }
    cout << v.size() << endl;
    for (auto it = v.begin(); it != v.end(); it++)
    {
        cout << *it << ' ';
    }
    return 0;
}