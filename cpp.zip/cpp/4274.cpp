#include <iostream>
#define ll long long
using namespace std;
ll k, m, n;
ll x, y;
bool flg;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> k >> m >> n;
    for (ll i = 0; i < m; i++)
    {
        cin >> x >> y;
        if (x == 0)
        {
            cout << i + 1 << ' ';
            continue;
        }
        if (k / x * y >= n)
        {
            cout << i + 1 << ' ';
            flg = 1;
        }
    }
    if (!flg)
    {
        cout << -1;
    }
    return 0;
}