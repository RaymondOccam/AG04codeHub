#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll x;
ll pow(ll a)
{
    ll b = x - 1;
    ll ans = 1;
    while (b > 0)
    {
        if (b & 1)
        {
            ans = ((ans % x) * (a % x)) % x;
        }
        a = a * a % x;
        b >>= 1;
    }
    return ans;
}
bool isprime()
{
    ll loop = 10;
    while (loop--)
    {
        ll t = rand();
        while (t % x == 0)
        {
            t = rand();
        }
        if (pow(t) != 1)
        {
            return false;
        }
    }
    return true;
}
ll cnt;
int main()
{
    for (x = 2; cnt <= 1000; x++)
    {
        if (isprime())
        {
            cnt++;
            cout << x << ",";
        }
    }
    return 0;
}