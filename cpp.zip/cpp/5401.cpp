#include <iostream>
#include <cmath>
#define ll long long
using namespace std;
ll cnt1, cnt2;
ll n;
ll a[114514];
ll b[114514];
ll res1, res2;
void func(ll l, ll r, ll c)
{
    b[l] += c;
    b[r + 1] -= c;
    return;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i];
        func(i, i, a[i]);
    }
    for (ll i = 1; i < n; i++)
    {
        if (b[i] > 0)
        {
            cnt1 += b[i];
        }
        else
        {
            cnt2 += b[i];
        }
    }
    cnt2 = abs(cnt2);
    res1 = (cnt1 >= cnt2 ? cnt1 : cnt2);
    res2 = abs(cnt1 - abs(cnt2)) + 1;
    cout << res1 << '\n' << res2;
    return 0;
}