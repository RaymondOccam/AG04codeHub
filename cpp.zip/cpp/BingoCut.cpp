#include <iostream>
#include <cmath>
#define ll long long
using namespace std;
ll t, ax, ay, bx, by, cx, cy;
ll res;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> t;
    while (t--)
    {
        cin >> ax >> ay >> bx >> by >> cx >> cy;
        res = min(abs(ax - bx), abs(ax - cx)) * ((ax - bx > 0) == (ax - cx > 0)) + min(abs(ay - by), abs(ay - cy)) * ((ay - by > 0) == (ay - cy > 0)) + 1;
        cout << res << '\n';
    }
    return 0;
}