#include <iostream>
#define ll long long
#define MAXN 100100
using namespace std;
ll n, m;
ll a[MAXN];
ll sum, l, res;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    while (l < n)
    {
        while (sum + a[l] <= m && l < n)
        {
            sum += a[l];
            l++;
        }
        sum = 0;
        res++;
    }
    cout << res;
    return 0;
}