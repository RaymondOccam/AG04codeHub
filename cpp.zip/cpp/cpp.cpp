#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll uk;
ll t;
ll mk;
string multiply(string num1, string num2)
{
    ll n1 = num1.size();
    ll n2 = num2.size();
    string result(n1 + n2, '0');
    for (ll i = n1 - 1; i >= 0; i--)
    {
        for (ll j = n2 - 1; j >= 0; j--)
        {
            ll digit1 = num1[i] - '0';
            ll digit2 = num2[j] - '0';
            ll product = digit1 * digit2;
            ll sum = product + (result[i + j + 1] - '0');
            result[i + j + 1] = sum % 10 + '0';
            result[i + j] += sum / 10;
        }
    }
    size_t pos = result.find_first_not_of('0');
    if (pos != string::npos)
    {
        return result.substr(pos);
    }
    return "0";
}
string jiecheng(ll p)
{
    string ans = "1";
    while (p > 1)
    {
        ans = multiply(ans, to_string(p));
        p--;
    }
    return ans;
}
string l;
ll cnt;
int main()
{
    cin >> t;
    while (t--)
    {
        cin >> uk >> mk;
        l = jiecheng(uk);
        char u = mk + '0';
        for (ll i = 0; l[i]; i++)
        {
            if (l[i] == u)
            {
                cnt++;
            }
        }
        cout << cnt << endl;
        cnt = 0;
    }
    return 0;
}