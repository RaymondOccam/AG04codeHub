#include <bits/stdc++.h>
#define ll long long
#define maxn 1000010
using namespace std;
ll a[maxn];
ll t, n;
ll circle(ll p)
{
    if (p < 10)
    {
        return p;
    }
    else if (p >= 10 && p < 100)
    {
        return 9 + p / 10;
    }
    else if (p >= 100 && p < 1000)
    {
        return 9 + 9 + p / 100;
    }
    else if (p >= 1000 && p < 10000)
    {
        return 9 + 9 + 9 + p / 1000;
    }
    else if (p >= 10000 && p < 100000)
    {
        return 9 + 9 + 9 + 9 + p / 10000;
    }
    else if (p >= 100000 && p < 1000000)
    {
        return 9 + 9 + 9 + 9 + 9 + p / 100000;
    }
}
ll m;
int main()
{
    cin >> t;
    while (t--)
    {
        cin >> n;
        cout << circle(n) << endl;
    }
    return 0;
}