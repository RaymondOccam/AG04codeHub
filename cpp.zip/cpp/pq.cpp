#include <iostream>
#include <queue>
#define ll long long
using namespace std;
struct Node
{
    ll x;
    friend bool operator<(Node a, Node b)
    {
        return a.x > b.x;
    }
};
priority_queue<Node> pq;
ll n, k;
ll t;
char ch;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> t;
    while (t--)
    {
        cin >> ch;
        if (ch == 'i')
        {
            cin >> k;
            pq.push(Node({k}));
        }
        else
        {
            cout << pq.top().x << '\n';
            pq.pop();
        }
    }
    return 0;
}