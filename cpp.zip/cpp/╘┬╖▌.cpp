#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    ll a, b, c;
    cin >> a >> b >> c;
    if (c == a && a == b)
    {
        cout << 1;
        return 0;
    }
    if (a % c == 0 && b % c == 0)
    {
        cout << (a / c) * (b / c);
    }
    else
    {
        cout << -1;
    }
    return 0;
}