#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n, y, h;
ll x, z;
ll ans;
bool inmtx(ll _a, ll _b, ll _o)
{
    return (_a < _o && _b < _o && _a >= 0 && _b >= 0 ? 1 : 0);
}
//inmtx:_a下标和_b下标是否在边长为_o的矩阵内
void setvalue_y(vector<vector<ll>> &_v, ll _x, ll _y)
{
    //定义偏移量
    ll _dx[13] = {0, 0, 0, -1, 1, -1, 1, -1, 1, -2, 2, 0, 0};
    ll _dy[13] = {0, -1, 1, 0, 0, -1, -1, 1, 1, 0, 0, -2, 2};
    for (ll _i = 0; _i < 13; _i++)
    {
        if (inmtx(_x + _dx[_i], _y + _dy[_i], _v.size()))
        {
            //如果_x, _y加上偏移量后还在矩阵内
            _v[_x + _dx[_i]][_y + _dy[_i]] = 1;
        }
    }
    return;
}
//在(_x, _y)的位置放置火把
void setvalue_h(vector<vector<ll>> &_v, ll _x, ll _y)
{
    //定义偏移量
    ll _dx[25] = {-2, -2, -2, -2, -2, -1, -1, -1, -1, -1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2};
    ll _dy[25] = {-2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2};
    for (ll _i = 0; _i < 25; _i++)
    {
        if (inmtx(_x + _dx[_i], _y + _dy[_i], _v.size()))
        {
            //如果_x, _y加上偏移量后还在矩阵内
            _v[_x + _dx[_i]][_y + _dy[_i]] = 1;
        }
    }
    return;
}
//在(_x, _y)的位置放置萤石
ll count(vector<vector<ll>> _v, ll _k)
{
    ll _cnt = 0;
    for (ll _i = 0; _i < _v.size(); _i++)
    {
        for (ll _j = 0; _j < _v.size(); _j++)
        {
            _cnt += (_v[_i][_j] == _k ? 1 : 0);
        }
    }
    return _cnt;
}
//有几个点没有光
int main()
{
    cin >> n >> y >> h;
    vector<vector<ll>> matrix(n, vector<ll>(n));
    for (ll i = 0; i < y; i++)
    {
        cin >> x >> z;
        setvalue_y(matrix, x - 1, z - 1);
        //摆放火把
    }
    for (ll i = 0; i < h; i++)
    {
        cin >> x >> z;
        setvalue_h(matrix, x - 1, z - 1);
        //摆放萤石
    }
    ans = count(matrix, 0);
    //计算有几个点没有光
    cout << ans;
    return 0;
}