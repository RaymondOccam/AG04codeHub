#include <iostream>
#define ll long long
using namespace std;
ll n, a;
ll sum[114514];
ll cnt;
ll m;
ll l, r;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> a;
        cnt += a;
        sum[i] = cnt;
    }
    cin >> m;
    while (m--)
    {
        cin >> l >> r;
        if (l == 1)
        {
            cout << sum[r - 1] << '\n';
        }
        else
        {
            cout << sum[r - 1] - sum[l - 2] << '\n';
        }
    }
    return 0;
}