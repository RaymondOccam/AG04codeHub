#include <iostream>
#include <vector>
#define ll long long
using namespace std;
class SegmentTree
{
private:
    vector<ll> tree;
    ll n;
    void buildTree(vector<ll> &arr)
    {
        n = arr.size();
        tree.resize(4 * n);
        for (ll i = 0; i < n; i++)
        {
            tree[n + i] = arr[i];
        }
        for (ll i = n - 1; i > 0; i--)
        {
            tree[i] = min(tree[2 * i], tree[2 * i + 1]);
        }
    }
    ll query(ll l, ll r)
    {
        l += n;
        r += n;
        ll minVal = 2147483647;
        while (l < r)
        {
            if (l % 2 == 1)
            {
                minVal = min(minVal, tree[l]);
                l++;
            }
            if (r % 2 == 1)
            {
                minVal = min(minVal, tree[r - 1]);
                r--;
            }
            l /= 2;
            r /= 2;
        }
        return minVal;
    }

public:
    SegmentTree(vector<ll> &arr)
    {
        buildTree(arr);
    }
    ll getMinimum(ll l, ll r)
    {
        return query(l, r);
    }
};
int main()
{
    
    return 0;
}