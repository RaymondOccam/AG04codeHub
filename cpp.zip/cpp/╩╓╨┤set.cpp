#include <iostream>
#include <vector>
#include <algorithm>
#include <set>
#define ll long long
#define MAXN 1000000ll
using namespace std;
ll Set[MAXN];
ll Idx;
namespace SetOp
{
    void MSort(ll l, ll m, ll r) // �鲢���ڲ���
    {
        ll i = l;
        ll j = m + 1;
        ll t[r - l + 1];
        ll k = 0;
        while (i <= m && j <= r)
        {
            if (Set[i] < Set[j])
            {
                t[k++] = Set[i++];
            }
            else
            {
                t[k++] = Set[j++];
            }
        }
        if (i <= m)
        {
            t[k++] = Set[i++];
        }
        if (j <= r)
        {
            t[k++] = Set[j++];
        }
        for (i = 0; i < k; i++)
        {
            Set[l++] = t[i];
        }
        return;
    }
    void Sort(ll l, ll r)
    {
        if (l == r)
        {
            return;
        }
        ll m = (l + r) >> 1;
        Sort(l, m);
        Sort(m + 1, r);
        MSort(l, m, r);
        return;
    }
    ll bs(ll l, ll r, ll v) // ����Ԫ���Ƿ���ڣ��ڲ���
    {
        ll mid;
        while (l <= r)
        {
            mid = (l + r) >> 1;
            if (Set[mid] == v)
            {
                return mid;
            }
            if (Set[mid] < v)
            {
                l = mid + 1;
            }
            else
            {
                r = mid - 1;
            }
        }
        return -1;
    }
    void Insert(ll x) // ����
    {
        if (Idx == 0)
        {
            Set[0] = x;
            Idx++;
            return;
        }
        Sort(0, Idx - 1);
        if (bs(0, Idx - 1, x) == -1)
        {
            Set[Idx] = x;
            Idx++;
            Sort(0, Idx - 1);
        }
        return;
    }
    void Erase(ll x) // ɾ��
    {
        if (Idx == 0)
        {
            return;
        }
        ll pos = bs(0, Idx - 1, x);
        Set[pos] = 0;
        while (pos < Idx - 1)
        {
            Set[pos] = Set[pos + 1];
        }
        return;
    }
    ll Size() // ��С
    {
        return Idx;
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    ll n;
    ll x;
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> x;
        SetOp::Insert(x);
    }
    cout << SetOp::Size();
    return 0;
}