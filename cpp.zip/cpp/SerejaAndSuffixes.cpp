#include <iostream>
#define ll long long
using namespace std;
ll a[100010];
ll b[100010];
ll s[100010];
ll n, m, cnt;
ll k;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    for (ll i = n - 1; i >= 0; i--)
    {
        if (b[a[i]] == 0)
        {
            b[a[i]]++;
            s[i] = ++cnt;
        }
        else
        {
            s[i] = cnt;
        }
    }
    while (m--)
    {
        cin >> k;
        cout << s[k - 1] << '\n';
    }
    return 0;
}