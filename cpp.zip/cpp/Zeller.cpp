#include <iostream>
#include <string>
#define ll long long
using namespace std;
ll yr = 2313;
ll mth = 1;
ll dt = 1;
ll f, y, m, w;
string res;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> yr >> mth >> dt;
    if (mth <= 2)
    {
        f++;
    }
    y = yr - f;
    m = mth + 12 * f - 2;
    w = dt + y + 31 * m / 12 + y / 4 - y / 100 + y / 400;
    w %= 7;
    // w = (d + y - f + 31 * (m + 12 * f - 2) / 12 + y / 4 - y / 100 + y / 400) % 7
    switch (w)
    {
        case 0:
            res = "��";
            break;
        case 1:
            res = "һ";
            break;
        case 2:
            res = "��";
            break;
        case 3:
            res = "��";
            break;
        case 4:
            res = "��";
            break;
        case 5:
            res = "��";
            break;
        case 6:
            res = "��";
            break;
        default:
            res = "һ��";
            break;
    }
    cout << "��һ��������" << res;
    return 0;
}