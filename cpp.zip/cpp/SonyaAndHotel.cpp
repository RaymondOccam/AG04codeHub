#include <iostream>
#define ll long long
#define MAXN 114
using namespace std;
ll n, d;
ll x[MAXN];
ll res = 2;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> d;
    for (ll i = 0; i < n; i++)
    {
        cin >> x[i];
    }
    for (ll i = 0; i < n - 1; i++)
    {
        if (x[i + 1] - x[i] > d * 2)
        {
            res += 2;
        }
        else if (x[i + 1] - x[i] == d * 2)
        {
            res++;
        }
    }
    cout << res;
    return 0;
}