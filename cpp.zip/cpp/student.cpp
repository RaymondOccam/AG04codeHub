#include <iostream>
#include <vector>
#define ll long long
using namespace std;
bool ia(vector<vector<ll>> &format, ll n, ll m, ll age1, ll age2)
{
    ll dx[] = {-1, 1, 0, 0};
    ll dy[] = {0, 0, -1, 1};
    pair<ll, ll> pos1;
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            if (format[i][j] == age1)
            {
                pos1 = make_pair(i, j);
                break;
            }
        }
    }
    for (ll i = 0; i < 4; i++)
    {
        ll nx = pos1.first + dx[i];
        ll ny = pos1.second + dy[i];
        if (nx >= 0 && nx < n && ny >= 0 && ny < m && format[nx][ny] == age2)
        {
            return true;
        }
    }
    return false;
}
ll age1, age2;
int main()
{
    ll n, m;
    cin >> n >> m;
    vector<vector<ll>> format(n, vector<ll>(m));
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            cin >> format[i][j];
        }
    }
    cin >> age1 >> age2;
    if (ia(format, n, m, age1, age2))
    {
        cout << "Y" << endl;
    }
    else
    {
        cout << "N" << endl;
    }
    return 0;
}