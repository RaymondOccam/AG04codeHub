#include <bits/stdc++.h>
#define ll long long
#define c "codeforces"
using namespace std;
ll t;
ll cnt;
string l;
int main()
{
    cin >> t;
    while (t--)
    {
        cnt = 0;
        cin >> l;
        for (ll i = 0; i < 10; i++)
        {
            if (l[i] != c[i])
            {
                cnt++;
            }
        }
        cout << cnt << endl;
    }
    return 0;
}