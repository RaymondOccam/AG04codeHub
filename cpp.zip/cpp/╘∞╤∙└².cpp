#include <iostream>
#include <vector>
#include <ctime>
#include <random>
#include <fstream>
#define ll long long
using namespace std;
ll cnt = -1;
int main()
{
    ll kk;
    cin >> kk;
    ofstream ofs;
    while (kk--)
    {
        cnt++;
        ofs.open(to_string(cnt) + ".in", ios::out);
        random_device rd;
        mt19937 gen(rd());
        srand(time(0));
        int x;
        x = rand() % 10000 + 2;
        ofs << x << endl;
        double ma, mb;
        uniform_real_distribution<double> dis(2.0, 10000.0);
        ma = dis(gen);
        mb = dis(gen);
        ofs << ma << ' ' << mb << endl;
        vector<int> a(x), b(x);
        for (int i = 0; i < x; i++)
        {
            a[i] = rand() % 10000 + 2;
            ofs << a[i] << ' ';
        }
        ofs << endl;
        for (int i = 0; i < x; i++)
        {
            b[i] = rand() % 10000 + 2;
            ofs << b[i] << ' ';
        }
        ofs << endl;
        ofs.close();
        ofs.open(to_string(cnt) + ".out", ios::out);
        ll total_time = 0;
        for (int i = 0; i < x; i++)
        {
            ll input_time = a[i] / 2 * 1000;
            ll send_time = ma * a[i];
            ll read_time = b[i] / 10 * 1000;
            total_time += input_time + send_time + read_time;
        }
        ofs << total_time << endl;
        ofs.close();
        continue;
    }
    return 0;
}