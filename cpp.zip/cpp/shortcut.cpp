#include <iostream>
#include <cmath>
#define ll long long
#define MAXN 6000000
using namespace std;
ll s, n;
ll l, r;
ll res = 0x7fffffffffffffff;
ll sum;
ll a[MAXN];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> s >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    while (r < n || sum >= s)
    {
        if (sum < s)
        {
            sum += a[r];
            r++;
        }
        if (sum >= s)
        {
            res = min(res, r - l);
            sum -= a[l];
            l++;
        }
    }
    if (res == 0x7fffffffffffffff)
    {
        res = 0;
    }
    cout << res;
    return 0;
}