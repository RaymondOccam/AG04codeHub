#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    
    return 0;
}