#include <iostream>
#define ll long long
using namespace std;
const ll N = 1e5 + 10;
ll a[N], nxt[N], pre[N], suf[N], n, m, T, l, r;
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    cin >> T;
    while (T--)
    {
        cin >> n;
        for (ll i = 1; i <= n; i++)
        {
            cin >> a[i];
        }
        for (ll i = 1; i <= n; i++)
        {
            if (i == 1)
            {
                nxt[i] = 2;
            }
            else if (i == n)
            {
                nxt[i] = n - 1;
            }
            else if (a[i] - a[i - 1] < a[i + 1] - a[i])
            {
                nxt[i] = i - 1;
            }
            else
            {
                nxt[i] = i + 1;
            }
        }
        for (ll i = 1; i <= n; i++)
        {
            if (nxt[i] == i + 1)
            {
                pre[i + 1] = pre[i] + 1;
            }
            else
            {
                pre[i + 1] = pre[i] + (a[i + 1] - a[i]);
            }
        }
        for (ll i = n; i >= 1; i--)
        {
            if (nxt[i] == i - 1)
            {
                suf[i - 1] = suf[i] + 1;
            }
            else
            {
                suf[i - 1] = suf[i] + (a[i] - a[i - 1]);
            }
        }
        cin >> m;
        while (m--)
        {
            cin >> l >> r;
            if (l <= r)
            {
                cout << pre[r] - pre[l] << '\n';
            }
            else
            {
                cout << suf[r] - suf[l] << '\n';
            }
        }
    }
    return 0;
}