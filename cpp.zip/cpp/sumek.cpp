#include <iostream>
#include <algorithm>
#define ll long long
using namespace std;
ll k, n, l, r, f;
ll a[50008];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> k >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    sort(a, a + n);
    r = n - 1;
    while (l < r)
    {
        if (a[l] + a[r] == k)
        {
            cout << a[l] << ' ' << a[r] << '\n';
            f = 1;
            l++, r--;
        }
        else if (a[l] + a[r] > k)
        {
            r--;
        }
        else
        {
            l++;
        }
    }
    if (!f)
    {
        cout << "No Solution";
    }
    return 0;
}