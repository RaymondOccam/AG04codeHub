#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    ll a, b, c, l;
    cin >> a >> b;
    c = log2(b / a + 1);
    l = b - (ll)(pow(2, c) - 1) * a;
    cout << (char)('A' + ceil(l / pow(2, c)) - 1);
    return 0;
}