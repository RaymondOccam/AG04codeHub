#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
const int MAX_N = 500;
const int MAX_M = 20000000;
int q;
int n, m;
int rd;
int main()
{
    int res[MAX_N][MAX_N] = {0};
    int plist[MAX_M] = {0};
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> q;
    while (q--)
    {
        int i, j;
        cin >> n >> m;
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < m; j++)
            {
                cin >> rd;
                plist[rd - 1] = j;
            }
        }
        for (i = 0; i < m; i++)
        {
            for (j = 0; j < n; j++)
            {
                cin >> rd;
                res[j][plist[rd - 1]] = rd;
            }
        }
        for (i = 0; i < n; i++)
        {
            for (j = 0; j < m; j++)
            {
                cout << res[i][j] << ' ';
            }
            cout << endl;
        }
    }
    return 0;
}