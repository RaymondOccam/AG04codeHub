#include <bits/stdc++.h>
#define ll long long
using namespace std;
inline void read(ll& a)
{
	ll s = 0, w = 1;
	char ch = getchar();
	while (ch < '0' || ch>'9')
	{
		if (ch == '-')
			w = -1;
		ch = getchar();
	}
	while (ch >= '0' && ch <= '9')
	{
		s = s * 10 + ch - '0';
		ch = getchar();
	}
	a = s * w;
}
int main()
{
    
    return 0;
}