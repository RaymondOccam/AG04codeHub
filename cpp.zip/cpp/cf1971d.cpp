#include <iostream>
#define ll long long
using namespace std;
void solve()
{
    string a;
    cin >> a;
    int ans = 1;
    for (int i = 1; i < a.size(); i++)
        if (a[i] != a[i - 1])
            ans++;
    if (ans == 1)
    {
        cout << "1" << endl;
        return;
    }
    if (a[0] == '0' || ans > 2)
        cout << ans - 1 << endl;
    else
        cout << ans << endl;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    solve();
    return 0;
}