#include <iostream>
#include <string>
#include <algorithm>
#define ll long long
using namespace std;
ll n;
struct Stud
{
    string nm;
    ll c, m, id, v = 1;
    bool flg = false;
} a[50010];
bool cmp1(Stud a, Stud b)
{
    return a.c > b.c;
}
bool cmp2(Stud a, Stud b)
{
    return a.m > b.m;
}
bool cmp3(Stud a, Stud b)
{
    return a.v < b.v || a.v == b.v && a.id < b.id;
}
int main()
{
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i].nm >> a[i].c >> a[i].m;
        a[i].id = i + 1;
    }
    sort(a, a + n, cmp1);
    ll i, q = 1;
    for (i = 0; i < n / 2 || a[i].c == a[i + 1].c; i++)
    {
        if (a[i].c != a[i + 1].c)
        {
            q = i;
        }
        a[i].v *= q;
        a[i].flg = true;
    }
    sort(a, a + n, cmp2);
    for (i = 0; i < n / 2 || a[i].m == a[i + 1].m; i++)
    {
        if (a[i].m != a[i + 1].m)
        {
            q = i;
        }
        a[i].v *= q;
        a[i].flg = true;
    }

    return 0;
}