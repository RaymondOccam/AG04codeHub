#include <stdio.h>
#define ll long long
const ll MAXN = 1e5;
ll n;
ll a[MAXN];
void tqsort(ll l, ll m, ll r)
{
    ll i = l;
    ll j = m + 1;
    ll t[r - l + 1];
    ll k = 0;
    while (i <= m && j <= r)
    {
        if (a[i] < a[j])
        {
            t[k++] = a[i++];
        }
        else
        {
            t[k++] = a[j++];
        }
    }
    while (i <= m)
    {
        t[k++] = a[i++];
    }
    while (j <= r)
    {
        t[k++] = a[j++];
    }
    for (i = 1; i <= n; i++)
    {
        a[l++] = t[i];
    }
    return;
}
void qsort(ll l, ll r)
{
    ll mid = (l + r) >> 1;
    qsort(l, mid);
    qsort(mid + 1, r);
    tqsort(l, mid, r);
    return;
}
int main()
{
    scanf("%lld%lld", &n);
    for (register ll i = 0; i < n; i++)
    {
        scanf("%lld", &a[i]);
    }
    qsort(0, n - 1);
    for (register ll i = 0; i < n; i++)
    {
        printf("%lld\n", a[i]);
    }
    return 0;
}