#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int main()
{
    int t;
    cin >> t;

    while (t--)
    {
        int n;
        cin >> n;

        vector<int> cities(n);
        for (int i = 0; i < n; i++)
        {
            cin >> cities[i];
        }

        int m;
        cin >> m;

        for (int i = 0; i < m; i++)
        {
            int x, y;
            cin >> x >> y;

            int minCoins;
            if (abs(cities[x - 1] - cities[y - 1]) < cities[y - 1] - cities[x - 1])
            {
                minCoins = abs(cities[x - 1] - cities[y - 1]);
            }
            else
            {
                minCoins = 1;
            }

            cout << minCoins << endl;
        }
    }

    return 0;
}