#include <iostream>
#include <string>
#include <algorithm>
#define ll long long
using namespace std;
string a[5378];
void zer(ll lear)
{
    for (ll i = 0; i < lear; i++)
    {
        a[i] = "0";
    }
    return;
}
string pls(string a, string b)
{
    string ans;
    ll carry = 0;
    ll sum;
    ll len;
    ll lena = a.size();
    ll lenb = b.size();
    ans.clear();
    len = max(a.size(), b.size());
    reverse(a.begin(), a.end());
    reverse(b.begin(), b.end());
    for (ll i = 0; i < len; i++)
    {
        sum = carry;
        if (i < lena)
        {
            sum += a[i] - '0';
        }
        if (i < lenb)
        {
            sum += b[i] - '0';
        }
        ans += sum % 10 + '0';
        carry = sum / 10;
    }
    if (carry)
    {
        ans += '1';
    }
    while (ans.back() == '0' && ans.size() > 1)
    {
        ans.pop_back();
    }
    reverse(ans.begin(), ans.end());
    return ans;
}
int main()
{
    ll x;
    cin >> x;
    zer(x);
    a[1] = "1";
    for (ll i = 2; i <= x + 1; i++)
    {
        a[i] = pls(a[i - 1], a[i - 2]);
    }
    if (x == 0)
    {
        cout << 0;
    }
    else
    {
        cout << a[x + 1];
    }
    return 0;
}