#include <iostream>
#include <vector>
using namespace std;
void merge(vector<int> &nums, int left, int mid, int right)
{
    vector<int> temp(right - left + 1);
    int i = left, j = mid + 1, k = 0;
    while (i <= mid && j <= right)
    {
        if (nums[i] <= nums[j])
        {
            temp[k++] = nums[i++];
        }
        else
        {
            temp[k++] = nums[j++];
        }
    }
    while (i <= mid)
    {
        temp[k++] = nums[i++];
    }
    while (j <= right)
    {
        temp[k++] = nums[j++];
    }
    for (k = 0; k < temp.size(); k++)
    {
        nums[left + k] = temp[k];
    }
}
void mergeSort(vector<int> &nums, int left, int right)
{
    if (left < right)
    {
        int mid = (left + right) / 2;
        mergeSort(nums, left, mid);
        mergeSort(nums, mid + 1, right);
        merge(nums, left, mid, right);
    }
}
int main()
{
    vector<int> nums = {5, 4, 3, 2, 1};
    mergeSort(nums, 0, nums.size() - 1);
    for (int num : nums)
    {
        cout << num << " ";
    }
    cout << endl;
    return 0;
}