#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n, k;
bool pr(ll pr_u)
{
    if (pr_u < 2)
    {
        return 0;
    }
    for (ll pr_i = 2; pr_i * pr_i <= pr_u; pr_i++)
    {
        if (pr_u % pr_i == 0)
        {
            return 0;
        }
    }
    return 1;
}
bool close(ll close_m, ll close_n)
{
    if (close_m == close_n)
    {
        return 0;
    }
    for (ll close_i = close_m + 1; close_i < close_n; close_i++)
    {
        if (pr(close_i))
        {
            return 0;
        }
    }
    return 1;
}
bool gpr(ll gpr_p)
{
    ll gpr_j;
    for (ll gpr_i = 2; gpr_i < gpr_p; gpr_i++)
    {
        gpr_j = gpr_p - 1 - gpr_i;
        if (pr(gpr_i) && pr(gpr_j) && close(gpr_i, gpr_j))
        {
            return 1;
        }
    }
    return 0;
}
ll cnt;
int main()
{
    cin >> n >> k;
    for (ll i = 2; i <= n; i++)
    {
        if (pr(i))
        {
            cnt += gpr(i);
        }
    }
    if (cnt >= k)
    {
        cout << "YES";
    }
    else
    {
        cout << "NO";
    }
    return 0;
}