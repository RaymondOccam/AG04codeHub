#include <iostream>
#define ll long long
using namespace std;
int main()
{
    cout << -1;
    return 0;
}