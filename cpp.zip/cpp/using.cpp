#include <bits/stdc++.h>
#include <exception>
#define ll long long
using namespace std;
int main()
{
    throw("");
}