#include <iostream>
#include <string>
#include <unordered_map>
#define ll long long
using namespace std;
ll n;
string str;
string s[20];
ll m, p;
unordered_map<string, ll> h;
ll g;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> s[i];
        h[s[i]] = 0;
    }
    for (ll i = 0; i < n; i++)
    {
        cin >> str;
        cin >> m >> p;
        if (p)
        {
            h[str] += m % p;
            h[str] -= m;
            m = m / p * p;
            for (ll i = 0; i < p; i++)
            {
                cin >> str;
                h[str] += m / p;
            }
        }
    }
    // for (register unordered_map<string, ll>::iterator it = h.begin(); it != h.end(); it++)
    // {
    //     cout << it->first << ' ' << it->second << '\n';
    // }
    for (ll i = 0; i < n; i++)
    {
        cout << s[i] << ' ' << h[s[i]] << '\n';
    }
    return 0;
}