#include <iostream>
#include <algorithm>
#define ll long long
#define MAXN 123
using namespace std;
ll n;
ll tar;
ll sum[MAXN][MAXN];
ll res = -0x8000000000000000;
/// @brief
/// @return
ll gsum(ll xa, ll ya, ll xb, ll yb)
{
    return sum[xb][yb] - sum[xb][ya - 1] - sum[xa - 1][yb] + sum[xa - 1][ya - 1];
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = 1; j <= n; j++)
        {
            cin >> tar;
            sum[i][j] = sum[i][j - 1] + sum[i - 1][j] - sum[i - 1][j - 1] + tar;
        }
    }
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = 1; j <= n; j++)
        {
            for (ll k = i; k <= n; k++)
            {
                for (ll l = j; l <= n; l++)
                {
                    res = max(res, gsum(i, j, k, l));
                }
            }
        }
    }
    cout << res;
    return 0;
}