#include <bits/stdc++.h>
#define ll long long
using namespace std;
struct Node
{
    ll num;
    ll cnt;
} a[10000];
ll n;
bool flag = false;
bool cmp(Node x, Node b)
{
    return x.num < b.num;
}
int main()
{
    cin >> n;
    ll u;
    for (ll i = 0; i < n; i++)
    {
        cin >> u;
        for (ll j = 0; j < n; j++) // u = 0
        {
            if (u == a[j].num)
            {
                a[j].cnt++;
                flag = true;
                break;
            }
        }
        if (flag == false)
        {
            a[i].num = u;
            a[i].cnt = 1;
        }
        flag = false;
        continue;
    }
    sort(a, a + n, cmp);
    for (ll i = 0; i < n; i++)
    {
        if (a[i].cnt != 0)
        {
            cout << a[i].num << ' ' << a[i].cnt << endl;
        }
    }
    return 0;
}