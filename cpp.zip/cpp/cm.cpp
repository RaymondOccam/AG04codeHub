#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll s, v;
ll tm;
const ll TIME = 6 * 80;
ll h, m;
int main()
{
    cin >> s >> v;
    tm = ceil(s / v) + 10;
    return 0;
}