#include <iostream>
#define ll long long
using namespace std;
ll a[110][110];
void solve()
{
    ll n, m;
    cin >> n >> m;
    bool f = 0;
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = 1; j <= m; j++)
        {
            cin >> a[i][j];
            if ((i == 1 || j == 1 || i == n || j == m) && a[i][j] == 1)
            {
                f = 1;
            }
        }
    }
    ll ans = f ? 2 : 4;
    cout << ans << '\n';
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    ll T;
    cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}