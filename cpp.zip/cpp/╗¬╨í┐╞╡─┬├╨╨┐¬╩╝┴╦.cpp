#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n, m;
ll sx, sy;
struct Place
{
    ll fst;
    ll scd;
};
Place hust[1010][1010];
int main()
{
    cin >> m >> n >> sx >> sy;
    ll px = sx;
    ll tpx = px;
    ll py = sy;
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = 1; j <= m; j++)
        {
            cin >> hust[i][j].fst >> hust[i][j].scd;
        }
    }
    while (1)
    {
        cout << px << ' ' << py << endl;
        tpx = hust[px][py].fst;
        py = hust[px][py].scd;
        px = tpx;
        if (px == 0 && py == 0)
        {
            break;
        }
    }
    return 0;
}