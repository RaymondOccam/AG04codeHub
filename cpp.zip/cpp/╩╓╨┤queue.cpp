#include <iostream>
#include <vector>
#define ll long long
using namespace std;
class ArrayQueue
{
private:
    vector<ll> q;

public:
    ArrayQueue() {}
    void enqueue(ll value)
    {
        q.push_back(value);
    }
    ll dequeue()
    {
        if (q.empty())
        {
            return;
        }
        ll value = q.front();
        q.erase(q.begin());
        return value;
    }
    bool isEmpty()
    {
        return q.empty();
    }
};
int main()
{
    
    return 0;
}