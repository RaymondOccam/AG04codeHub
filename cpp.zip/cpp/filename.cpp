#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
string s;
ll cnt;
int main()
{
    cin >> n;
    cin >> s;
    if (s.find("xxx") == string::npos)
    {
        cout << 0;
        return 0;
    }
    while (s.find("xxx") != string::npos)
    {
        s.erase(s.find("xxx"), 1);
        cnt++;
    }
    cout << cnt;
    return 0;
}