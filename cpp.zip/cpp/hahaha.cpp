#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    ofstream ofs;
    ofs.open("0.cpp", ios::out);
    ofs << "#include <bits/stdc++.h>\n"
            "#define ll long long\n"
            "using namespace std;\n"
            "int main()\n"
            "{\n";
    for (ll i = 0; i < 1e6; i++)
    {
        ofs << "    cout << \"hello world\" << endl;" << endl;
    }
    ofs << "return 0;\n";
    ofs << "}\n";
    ofs.close();
    return 0;
}