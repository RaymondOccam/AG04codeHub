#include <iostream>
#define ll long long
using namespace std;
ll n, a;
ll sum[114514];
ll cnt;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> a;
        cnt += a;
        sum[i] = cnt;
    }
    cout << n << '\n';
    for (ll i = 0; i < n; i++)
    {
        cout << sum[i] << '\n';
    }
    return 0;
}