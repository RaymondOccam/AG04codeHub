#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n, m;
ll a1, a2;
ll stud[10000][10000];
int main()
{
    cin >> n >> m;
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            cin >> stud[i][j];
        }
    }
    cin >> a1 >> a2;
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < m; j++)
        {
            if (stud[i][j] == a1)
            {
                if ((stud[i + 1][j] == a2 && i < n - 1) || (stud[i - 1][j] == a2 && i > 0) ||
                    (stud[i][j + 1] == a2 && j < m - 1) || (stud[i][j - 1] == a2 && j > 0))
                {
                    cout << 'Y';
                    return 0;
                }
                continue;
            }
        }
    }
    cout << 'N';
    return 0;
}