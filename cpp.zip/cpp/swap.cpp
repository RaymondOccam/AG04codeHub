#include <iostream>
#include <map>
#include <cmath>
#include <algorithm>
#define ll long long
using namespace std;
ll n, a, res;
map<ll, ll> m;
map<ll, bool> vis;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 1; i <= n; i++)
    {
        cin >> a;
        m[a] = i + 1;
    }
    for (ll i = 1; i <= n; i++)
    {
        if (m[i] != i)
        {
            res++;
            swap(m[i], m[m[i]]);
        }
    }
    cout << res;
    return 0;
}