#include <bits/stdc++.h>
#define ll long long
using namespace std;
struct Node
{
    ll exist;
    ll cost;
};
ll n, m;
vector<Node> v;
bool cmp(Node x, Node y)
{
    return x.cost > y.cost;
}
ll t;
ll ans;
ll b;
int main()
{
    cin >> n >> m;
    v.resize(n);
    for (ll i = 0; i < n; i++)
    {
        cin >> v[i].exist;
    }
    for (ll i = 0; i < n; i++)
    {
        cin >> v[i].cost;
    }
    sort(v.begin(), v.end(), cmp);
    for (ll i = 0; i < n; i++)
    {
        if (t < v[i].exist && b < m)
        {
            ans += v[i].cost;
            t++;
            b++;
        }
        else
        {
            continue;
        }
    }
    cout << ans;
    return 0;
}