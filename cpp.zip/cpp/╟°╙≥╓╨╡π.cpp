#include <iostream>
#include <vector>

using namespace std;

vector<int> getMidPoint(const vector<int> &start, const vector<int> &end)
{
    vector<int> mid(3);
    for (int i = 0; i < 3; i++)
    {
        mid[i] = (start[i] + end[i]) / 2;
    }
    return mid;
}

int main()
{
    vector<int> start = {6, 7, 22};  // ���
    vector<int> end = {17, 16, 31}; // �յ�
    vector<int> mid = getMidPoint(start, end);
    cout << "�е�Ϊ��" << endl;
    for (int i = 0; i < 3; i++)
    {
        cout << "��" << i + 1 << "ά��" << mid[i] << endl;
    }
    return 0;
}