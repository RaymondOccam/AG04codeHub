#include <iostream>
#include <algorithm>
#include <string>
#include <vector>
#include <set>
#define ll long long
using namespace std;
int n;
struct Stud
{
    string nm;
    int che;
    int mth;
    ll id;
    int cheid;
    int mthid;
    bool flag = true;
    // id_max = n_max * n_max = 5e4 * 5e4 = 2.5e9
    // int_max �� 2.1e9�����Կ�long long
} cls[50000], yes[50000];
bool cmp1(Stud &a, Stud &b)
{
    return a.che > b.che;
}
bool cmp2(Stud a, Stud b)
{
    return a.mth > b.mth;
}
bool cmp3(Stud a, Stud b)
{
    return a.id < b.id;
}
int chihg;
int mthhg;
bool is_output = false;
set<int> alctc;
set<int> alctm;
int pos;
int main()
{
    
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> cls[i].nm >> cls[i].che >> cls[i].mth;
    }
    sort(cls, cls + n, cmp1);
    for (int i = 0; i < n; i++)
    {
        cls[i].cheid = i + 1;
        alctc.insert(cls[i].cheid);
    }
    sort(cls, cls + n, cmp2);
    for (int i = 0; i < n; i++)
    {
        cls[i].id = cls[i].cheid * (i + 1);
        cls[i].mthid = i + 1;
        alctm.insert(cls[i].mthid);
    }
    set<int>::iterator it = alctc.begin();
    int temp = alctc.size() / 2;
    for (int i = 0; i < temp; i++)
    {
        it++;
    }
    chihg = *it;
    it = alctm.begin();
    temp = alctm.size() / 2;
    for (int i = 0; i < temp; i++)
    {
        it++;
    }
    mthhg = *it;
    for (int i = 0; i < n; i++)
    {
        if (cls[i].cheid <= chihg && cls[i].mthid <= mthhg)
        {
            yes[pos] = cls[i];
            pos++;
        }
    }
    sort(yes, yes + pos, cmp3);
    for (int i = 0; i < pos; i++)
    {
        cout << yes[i].nm << endl;
    }
    return 0;
}