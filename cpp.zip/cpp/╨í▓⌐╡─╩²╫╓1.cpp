#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll fm, fz;
ll ito(ll a, ll b)
{
    ll ans = 0;
    ll temp;
    while (a)
    {
        temp = a % b;
        a /= b;
        ans += temp;
    }
    return ans;
}
ll s;
ll pres;
ll alter;
int main()
{
    ll a;
    ll val;
    cin >> a;
    for (ll i = 2; i < a; i++)
    {
        val = ito(a, i);
        pres += val;
        s++;
    }
    alter = __gcd(pres, s);
    cout << pres / alter << '/' << s / alter;
    return 0;
}