#include <iostream>
#define ll long long
using namespace std;
ll n;
ll s[1014514];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> s[i];
    }
    cout << s[0] << ' ';
    for (ll i = 1; i < n; i++)
    {
        cout << s[i] - s[i - 1] << ' ';
    }
    return 0;
}