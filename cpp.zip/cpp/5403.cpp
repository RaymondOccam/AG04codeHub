#include <iostream>
#include <algorithm>
#define ll long long
using namespace std;
ll n, l, r;
ll a[2000000];
ll maxn = -1;
ll maxnn = -1;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> l >> r;
        a[l]++;
        a[r + 1]--;
        maxnn = max(maxnn, r + 1);
    }
    for (ll i = 1; i < maxnn; i++)
    {
        a[i] += a[i - 1];
    }
    for (ll i = 0; i < maxnn; i++)
    {
        maxn = max(maxn, a[i]);
    }
    cout << maxn;
    return 0;
}