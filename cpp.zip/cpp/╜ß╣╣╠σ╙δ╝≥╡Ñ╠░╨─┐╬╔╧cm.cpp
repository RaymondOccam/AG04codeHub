#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
bool cmp(pair<ll, ll> x, pair<ll, ll> y)
{
    if (x.first != y.first)
    {
        return x.first < y.first;
    }
    else
    {
        return x.second < y.second;
    }
}
int main()
{
    cin >> n;
    vector<pair<ll, ll>> st(n);
    for (ll i = 0; i < n; i++)
    {
        cin >> st[i].first >> st[i].second;
    }
    sort(st.begin(), st.end(), cmp);
    for (ll i = 0; i < n; i++)
    {
        cout << st[i].first << ' ' << st[i].second << endl;
    }
    return 0;
}