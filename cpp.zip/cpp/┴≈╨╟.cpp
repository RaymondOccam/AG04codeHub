#include <iostream>
#include <cstdio>
#include <cstring>
#define ll long long
using namespace std;
ll m;
ll peg[350][350], perr[350][350];
ll res = 0x7fffffffffffffff;
ll x, y, t;
void dfs(ll x, ll y, ll t)
{
    if (peg[x][y] <= t || t >= res || t >= perr[x][y])
    {
        return;
    }
    perr[x][y] = t;
    dfs(x + 1, y, t + 1);
    if (x - 1 >= 0)
    {
        dfs(x - 1, y, t + 1);
    }
    dfs(x, y + 1, t + 1);
    if (y - 1 >= 0)
    {
        dfs(x, y - 1, t + 1);
    }
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    for (ll i = 0; i < 350; i++)
    {
        for (ll j = 0; j < 350; j++)
        {
            peg[i][j] = 0x7fffffffffffffff;
        }
    }
    for (ll i = 0; i < 350; i++)
    {
        for (ll j = 0; j < 350; j++)
        {
            perr[i][j] = 0x7fffffffffffffff;
        }
    }
    cin >> m;
    for (ll i = 0; i < m; i++)
    {
        cin >> x >> y >> t;
        peg[x][y] = min(peg[x][y], t);
        peg[x + 1][y] = min(peg[x + 1][y], t);
        if (!(x - 1))
        {
            peg[x - 1][y] = min(peg[x - 1][y], t);
        }
        peg[x][y + 1] = min(peg[x][y + 1], t);
        if (!(y - 1))
        {
            peg[x][y - 1] = min(peg[x][y - 1], t);
        }
    }
    dfs(0, 0, 0);
    if (res == 0x7fffffffffffffff)
    {
        cout << -1 << '\n';
        return 0;
    }
    cout << res << '\n';
    return 0;
}