#include <iostream>
#define ll long long
#define MAXN 10050
using namespace std;
ll a[MAXN];
bool vis[MAXN];
ll res;
ll n;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    for (ll i = 1; i <= n; i++)
    {
        if (!vis[i])
        {
            res++;
            for (ll p = i; !vis[p]; p = a[p])
            {
                vis[p] = 1;
            }
        }
    }
    res = n - res;
    cout << res;
    return 0;
}