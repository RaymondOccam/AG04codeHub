#include <iostream>
#include <string>
#define ll long long
using namespace std;
string s;
ll t, n;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> t;
    while (t--)
    {
        cin >> n;
        cin >> s;

    }
    return 0;
}