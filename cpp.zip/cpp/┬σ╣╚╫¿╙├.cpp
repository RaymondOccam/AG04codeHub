#include <iostream>
#define ll long long
using namespace std;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cout << "The 1500'th ugly number is 859963392.\n";
    return 0;
}