#include <iostream>
#include <fstream>
#include <random>

using namespace std;

// 生成随机数
long long generateRandomNumber(long long min, long long max)
{
    random_device rd;
    mt19937_64 gen(rd());
    uniform_int_distribution<long long> dis(min, max);
    return dis(gen);
}

// 生成样例文件
void generateTestCase(int op)
{
    for (int i = 1; i <= op; i++)
    {
        string inFileName = to_string(i) + ".in";
        string outFileName = to_string(i) + ".out";
        ofstream inFile(inFileName);
        ofstream outFile(outFileName);

        // 生成题目描述中的变量
        int n = generateRandomNumber(1, 10000);
        int s = generateRandomNumber(1, 10000);
        int m = generateRandomNumber(1, 10000);

        // 写入题目描述
        inFile << n << " " << s << " " << m << endl;

        // 生成n个数组
        for (int j = 1; j <= n; j++)
        {
            // 生成m个随机数
            for (int k = 0; k < m; k++)
            {
                long long num = generateRandomNumber(2, 1000000000000);
                inFile << num << " ";
            }
            inFile << endl;

            // 写入数组编号
            inFile << j << endl;
        }

        // 写入要输出的数组编号
        outFile << s << endl;

        inFile.close();
        outFile.close();
    }
}

int main()
{
    int op;
    cin >> op;
    generateTestCase(op);
    return 0;
}