#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
	string vs[200000] = {0};
	return 0;
}