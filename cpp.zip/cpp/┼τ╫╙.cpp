#include <cstdio>
#include <iostream>
#include <cstring>
#define MAXN 2147483647
#define ll long long
using namespace std;
ll m, peg[350][350], f[350][350], res = 0x7fffffff;
void dfs(ll x, ll y, ll t)
{
    if (peg[x][y] <= t || t >= res || t >= f[x][y])
    {
        return;
    }
    f[x][y] = t;
    if (peg[x][y] > (ll)(1e9))
    {
        res = min(t, res);
        {
            return;
        }
    }
    dfs(x + 1, y, t + 1);
    if (x - 1 >= 0)
        dfs(x - 1, y, t + 1);
    dfs(x, y + 1, t + 1);
    if (y - 1 >= 0)
        dfs(x, y - 1, t + 1);
}
ll x, y, t;
int main()
{
    memset(peg, 0x3f, sizeof(peg));
    memset(f, 0x3f, sizeof(f));
    cin >> m;
    for (ll i = 0; i < m; i++)
    {
        cin >> x >> y >> t;
        peg[x][y] = min(peg[x][y], t);
        peg[x + 1][y] = min(peg[x + 1][y], t);
        if (x - 1 >= 0)
        {
            peg[x - 1][y] = min(peg[x - 1][y], t);
        }
        peg[x][y + 1] = min(peg[x][y + 1], t);
        if (y - 1 >= 0)
        {
            peg[x][y - 1] = min(peg[x][y - 1], t);
        }
    }
    dfs(0, 0, 0);
    if (res == 0x7fffffff)
    {
        cout << -1;
        return 0;
    }
    cout << res;
    return 0;
}