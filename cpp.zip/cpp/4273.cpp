#include <iostream>
#include <string>
#include <cmath>
#define ll long long
using namespace std;
ll m;
string n;
ll s;
ll res;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> m >> n;
    s = n.size() - 1;
    while (n.size() > 1 && n.back() == '0')
    {
        n.pop_back();
    }
    for (ll i = 0; n[i]; i++)
    {
        res = n[i] - '0';
        if (res != 0)
        {
            cout << n[i] << '*' << m << '^' << s - i;
            if (i < n.size() - 1)
            {
                cout << '+';
            }
        }
    }
    return 0;
}