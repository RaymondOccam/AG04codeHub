#include <bits/stdc++.h>
#define ll long long
using namespace std;
char a, b, c, d, e, f, g, h, i, j;
ll sum;
int main()
{
    scanf("%c-%c%c%c-%c%c%c%c%c-%c", &a, &b, &c, &d, &e, &f ,&g ,&h ,&i, &j);
    sum += (a - '0') * 1;
    sum += (b - '0') * 2;
    sum += (c - '0') * 3;
    sum += (d - '0') * 4;
    sum += (e - '0') * 5;
    sum += (f - '0') * 6;
    sum += (g - '0') * 7;
    sum += (h - '0') * 8;
    sum += (i - '0') * 9;
    if (sum % 11 == 10)
    {
        if (j == 'X')
        {
            cout << "Right";
        }
        else
        {
            cout << a << '-' << b << c << d << '-' << e << f << g << h << i << '-' << 'X';
        }
    }
    else
    {
        if (sum % 11 == (j - '0'))
        {
            cout << "Right";
        }
        else
        {
            cout << a << '-' << b << c << d << '-' << e << f << g << h << i << '-' << sum % 11;
        }
    }
    cout << flush;
    return 0;
}