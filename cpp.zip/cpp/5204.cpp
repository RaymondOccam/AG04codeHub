#include <iostream>
#include <algorithm>
#define ll long long
using namespace std;
ll n, m, a;
ll b[5114514];
ll x, y, z;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 0; i < n; i++)
    {
        cin >> a;
        b[i] += a;
        b[i + 1] -= a;
    }
    while (m--)
    {
        cin >> x >> y >> z;
        b[x - 1] += z;
        b[y] -= z;
    }
    for (ll i = 1; i < n; i++)
    {
        b[i] += b[i - 1];
    }
    sort(b, b + n);
    cout << b[0];
    return 0;
}