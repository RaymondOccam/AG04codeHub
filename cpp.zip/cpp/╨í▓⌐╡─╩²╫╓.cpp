#include <iostream>
#include <string>
#include <vector>
#include <stdlib.h>
#include <cstring>
#include <algorithm>
#define ll long long
using namespace std;
ll baseten;
vector<ll> sum;
char res[114514];
ll nsum(char rl[], ll s)
{
    ll sum = 0;
    for (ll i = 0; i < s; i++)
    {
        sum += rl[i] - 48;
    }
    return sum;
}
ll op;
ll op1;
int main()
{
    ll sm = 0;
    cin >> baseten;
    for (ll i = 2; i < baseten; i++)
    {
        itoa(baseten, res, i);
        ll sl = strlen(res);
        op = nsum(res, sl);
        op1 += sl;
        sum.push_back(op);
    }
    cout << op1 / __gcd(op1, (ll)sum.size()) << '/' << sum.size() / __gcd(op1, (ll)sum.size());
    return 0;
}