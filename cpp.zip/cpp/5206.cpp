#include <iostream>
#define ll long long
using namespace std;
ll n, m;
ll l, r;
ll res;
ll chf[1000050];
void f(ll l, ll r, ll c)
{
    l--;
    r--;
    chf[l] += c;
    chf[r + 1] -= c;
    return;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 0; i < m; i++)
    {
        cin >> l >> r;
        f(l, r, 1);
    }
    res = chf[0] % 2;
    for (ll i = 1; i < n; i++)
    {
        chf[i] += chf[i - 1];
        res += chf[i] % 2;
    }
    cout << res;
    return 0;
}