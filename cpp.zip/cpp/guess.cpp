#include <bits/stdc++.h>
#define ll long long
using namespace std;
string n, m;
ll cnt;
int main()
{
    cin >> n >> m;
    if (n == "0" && m == "0")
    {
        cout << "OK";
        return 0;
    }
    if (m[0] == '0')
    {
        cout << "WRONG_ANSWER";
        return 0;
    }
    sort(n.begin(), n.end());
    for (ll i = 0; i < n.size(); i++)
    {
        if (n[i] != '0')
        {
            swap(n[0], n[i]);
            break;
        }
    }
    if (n == m)
    {
        cout << "OK";
    }
    else
    {
        cout << "WRONG_ANSWER";
    }
    return 0;
}