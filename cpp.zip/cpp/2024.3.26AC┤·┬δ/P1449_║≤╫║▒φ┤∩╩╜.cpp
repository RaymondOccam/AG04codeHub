#include <iostream>
#include <stack>
#define ll long long
using namespace std;
char sarr[114514];
ll res, k;
stack<ll> s;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> sarr;
    for (ll i = 0; sarr[i] != '@'; i++)
    {
        if (sarr[i] == '.')
        {
            res = 0, k = 1;
            for (ll j = i - 1; j >= 0 && sarr[j] >= '0' && sarr[j] <= '9'; j--)
            {
                res = res + (sarr[j] - 48) * k;
                k *= 10;
            }
            s.push(res);
            continue;
        }
        if (sarr[i] >= '0' && sarr[i] <= '9')
        {
            continue;
        }
        res = s.top();
        s.pop();
        if (sarr[i] == '+')
        {
            res = s.top() + res;
        }
        if (sarr[i] == '-')
        {
            res = s.top() - res;
        }
        if (sarr[i] == '*')
        {
            res = s.top() * res;
        }
        if (sarr[i] == '/')
        {
            res = s.top() / res;
        }
        s.pop();
        s.push(res);
    }
    cout << s.top();
    return 0;
}