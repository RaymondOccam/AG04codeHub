#include <iostream>
#include <string>
#include <unordered_map>
#define ll long long
using namespace std;
unordered_map<ll, bool> Hash;
string str;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> str;
    for (ll i = 0; str[i]; i++)
    {
        if (str[i] == ')')
        {
            for (ll j = i; j >= 0; j--)
            {
                if (!Hash[j] && str[j] == '(')
                {
                    Hash[i] = true;
                    Hash[j] = true;
                    break;
                }
                if (!Hash[j] && str[j] == '[')
                {
                    break;
                }
            }
        }
        else if (str[i] == ']')
        {
            for (ll j = i; j >= 0; j--)
            {
                if (!Hash[j] && str[j] == '[')
                {
                    Hash[i] = true;
                    Hash[j] = true;
                    break;
                }
                if (!Hash[j] && str[j] == '(')
                {
                    break;
                }
            }
        }
    }
    for (ll i = 0; str[i]; i++)
    {
        if ((str[i] == '(' || str[i] == ')') && Hash[i] == false)
        {
            cout << "()";
        }
        else if (Hash[i] == false)
        {
            cout << "[]";
        }
        else
        {
            cout << str[i];
        }
    }
    return 0;
}