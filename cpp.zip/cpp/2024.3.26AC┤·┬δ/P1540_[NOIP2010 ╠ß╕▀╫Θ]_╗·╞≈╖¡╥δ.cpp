#include <iostream>
#include <queue>
#define ll long long
using namespace std;
ll m, n;
ll rd;
queue<ll> q;
ll res;
ll a[6865];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> m >> n;
    while (n--)
    {
        cin >> rd;
        if (a[rd] == 0)
        {
            q.push(rd);
            res++;
            a[rd] = 1;
            if (q.size() > m)
            {
                a[q.front()] = 0;
                q.pop();
            }
        }
    }
    cout << res;
    return 0;
}