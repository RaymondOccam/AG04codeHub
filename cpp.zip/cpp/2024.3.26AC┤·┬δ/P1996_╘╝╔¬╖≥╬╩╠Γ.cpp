#include <iostream>
#include <queue>
#define ll long long
using namespace std;
ll n, m;
queue<ll> op;
ll cnt = 1;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 0; i < n; i++)
    {
        op.push(i + 1);
    }
    while (!op.empty())
    {
        if (cnt == m)
        {
            cout << op.front() << ' ';
            op.pop();
            cnt = 1;
        }
        else
        {
            cnt++;
            op.push(op.front());
            op.pop();
        }
    }
    return 0;
}