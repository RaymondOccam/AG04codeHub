#include <iostream>
#include <iomanip>
#include <string>
#include <stack>
#define ld long double
#define ll long long
using namespace std;
string s, x;
stack<ld> st;
ll d;
ld val1, val2;
ld res;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    getline(cin, s);
    s = ' ' + s;
    for (ll i = s.size() - 1; i >= 0; i--)
    {
        if (s[i] == ' ')
        {
            x = s.substr(i + 1, d);
            if (x != "+" && x != "-" && x != "*" && x != "/")
            {
                st.push(stod(x));
            }
            else
            {
                val1 = st.top();
                st.pop();
                val2 = st.top();
                st.pop();
                if (x == "+")
                {
                    val1 += val2;
                    st.push(val1);
                }
                else if (x == "-")
                {
                    val1 -= val2;
                    st.push(val1);
                }
                else if (x == "*")
                {
                    val1 *= val2;
                    st.push(val1);
                }
                else
                {
                    val1 /= val2;
                    st.push(val1);
                }
            }
            // "insert add 1"
            // "012345678911"
            // "012345678901"
            d = 0;
        }
        else
        {
            d++;
        }
    }
    cout << fixed << setprecision(6) << st.top();
    return 0;
}