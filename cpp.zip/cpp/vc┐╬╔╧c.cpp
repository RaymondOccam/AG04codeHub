#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll n, x, y;
ll k;
int main()
{
    cin >> n >> k;
    vector<ll> v(n);
    for (ll i = 0; i < n; i++)
    {
        cin >> v[i];
    }
    for (ll i = 0; i < k; i++)
    {
        if (getchar() == 'D')
        {
            cin >> x;
            if (x > v.size())
            {
                continue;
            }
            v.erase(v.begin() + x);
        }
        else if (getchar() == 'Z')
        {
            cin >> x >> y;
            if (x > v.size())
            {
                continue;
            }
            v.insert(v.begin() + x, y);
        }
    }
    cout << v.size() << endl;
    for (auto it = v.begin(); it != v.end(); it++)
    {
        cout << *it << ' ';
    }
    return 0;
}