#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

#define ll long long

struct ListNode
{
    ll val;
    ListNode *next;
    ListNode(ll x) : val(x), next(nullptr) {}
};

ListNode *createList(int n)
{
    ListNode *head = new ListNode(1);
    ListNode *tail = head;
    for (int i = 2; i <= n; i++)
    {
        tail->next = new ListNode(i);
        tail = tail->next;
    }
    return head;
}

void printList(ListNode *head)
{
    while (head)
    {
        cout << head->val << " -> ";
        head = head->next;
    }
    cout << "nullptr" << endl;
}

int main()
{
    ll n;
    cin >> n;
    ListNode *head = createList(n);
    printList(head);
    return 0;
}