#include <iostream>
#include <cmath>
#define ll long long
using namespace std;
ll n;
ll x;
ll a[114514];
ll cnt1, cnt2;
void func(ll l, ll r, ll c)
{
    a[l] -= c;
    a[r + 1] += c;
    return;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        cin >> x;
        func(i, i, x);
    }
    for (ll i = 0; i < n; i++)
    {
        if (a[i] > 0)
        {
            cnt1 += a[i];
        }
        else
        {
            cnt2 -= a[i];
        }
    }
    cout << max(cnt1, cnt2);
    return 0;
}