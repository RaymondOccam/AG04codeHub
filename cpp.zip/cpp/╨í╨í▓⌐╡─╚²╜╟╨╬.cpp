#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll l[4];
int main()
{
    for (ll i = 0; i < 4; i++)
    {
        cin >> l[i];
    }
    sort(l, l + 4);
    if (l[0] + l[1] > l[2] || l[1] + l[2] > l[3])
    {
        cout << "TRIANGLE";
    }
    else if (l[0] + l[1] == l[2] || l[1] + l[2] == l[3])
    {
        cout << "SEGMENT";
    }
    else
    {
        cout << "IMPOSSIBLE";
    }
    return 0;
}