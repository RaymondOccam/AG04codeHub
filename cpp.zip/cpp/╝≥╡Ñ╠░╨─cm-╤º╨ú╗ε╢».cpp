#include <bits/stdc++.h>
#define ll long long
using namespace std;
struct Activity
{
    ll begin;
    ll end;
};
bool cmp(const Activity &a, const Activity &b)
{
    return a.end < b.end;
}
int main()
{
    ll n;
    cin >> n;
    vector<Activity> ac(n);
    for (ll i = 0; i < n; i++)
    {
        cin >> ac[i].begin >> ac[i].end;
    }
    sort(ac.begin(), ac.end(), cmp);
    ll count = 1;
    ll end = ac[0].end;
    for (ll i = 1; i < n; i++)
    {
        if (ac[i].begin >= end)
        {
            count++;
            end = ac[i].end;
        }
    }
    cout << count << endl;
    return 0;
}