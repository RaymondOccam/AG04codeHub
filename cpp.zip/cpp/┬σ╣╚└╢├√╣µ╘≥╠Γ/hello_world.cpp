#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main()
{
    cout << __gcd(9, 8);
    return 0;
}