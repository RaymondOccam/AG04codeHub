#include <bits/stdc++.h>
#define ll long long
using namespace std;
string str;
ll cnt[1000];
ll knt;
int main()
{
    cin >> str;
    for (ll i = 0; i < str.size(); i++)
    {
        cnt[str[i] - '0']++;
    }
    for (ll i = 0; i < 1000; i++)
    {
        if (cnt[i] >= 1)
        {
            knt++;
        }
    }
    if (knt >= 5)
    {
        cout << "Yes";
    }
    else
    {
        cout << "No";
    }
    return 0;
}