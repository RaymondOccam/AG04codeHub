#include <iostream>
#include <algorithm>
#define ll long long
#define MAXN 100099
using namespace std;
ll n, k;
ll a[MAXN];
ll res;
ll minn = 0x7fffffffffffffff;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    if (k == 1)
    {
        sort(a, a + n);
        res = a[0];
        if (n == 1)
        {
            cout << a[0] << '\n';
            return 0;
        }
        for (ll i = 1; i < n - 1; i++)
        {
            res -= a[i];
        }
        cout << a[n - 1] - res << '\n';
    }
    else
    {
        for (ll i = 0; i < n; i++)
        {
            minn = min(minn, a[i]);
        }
        cout << minn << '\n';
    }
    return 0;
}