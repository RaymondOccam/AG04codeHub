#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll cnt;
vector<ll> v;
ll n;
ll x;
ll minn, maxn;
int main()
{
    cin >> n;
    cin >> x;
    v.push_back(x);
    for (ll i = 1; i < n; i++)
    {
        minn = *min_element(v.begin(), v.end());
        maxn = *max_element(v.begin(), v.end());
        cin >> x;
        v.push_back(x);
        if (x < minn || x > maxn)
        {
            cnt++;
        }
    }
    cout << cnt;
    return 0;
}