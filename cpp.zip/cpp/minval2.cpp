#include <iostream>
#include <algorithm>
#include <queue>
#define ll long long
#define MAXN 10050
using namespace std;
struct Node
{
    ll x;
    friend bool operator<(Node p, Node q)
    {
        return p.x > q.x;
    }
} g;
ll n, m;
ll q;
ll temp[MAXN];
ll a[MAXN], b[MAXN], c[MAXN];
priority_queue<Node> pq;
ll func(ll ap, ll bp, ll cp, ll x)
{
    return ap * x * x + bp * x + cp;
}
ll t;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 0; i < n; i++)
    {
        cin >> a[i] >> b[i] >> c[i];
    }
    t = m / n + 1;
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 1; j <= t; j++)
        {
            q = func(a[i], b[i], c[i], j);
            g.x = q;
            pq.push(g);
        }
    }
    
    // if (t * n < m)
    // {
    //     for (ll i = 0; i < n; i++)
    //     {
    //         q = func(a[i], b[i], c[i], t + 1);
    //         temp[i] = q;
    //     }
    //     sort(temp, temp + n);
    //     for (ll i = t * n; i < m; i++)
    //     {
    //         pq.push(Node({temp[i]}));
    //     }
    // }
    while (m--)
    {
        cout << pq.top().x << ' ';
        pq.pop();
    }
    return 0;
}