#include <iostream>
#include <map>
#define ll long long
#define MAXN 100050
using namespace std;
ll n, k, res;
ll x;
ll sum[MAXN];
map<ll, ll> m;
ll val;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> k;
    cin >> x;
    sum[0] = x;
    m[0] = 1;
    for (ll i = 1; i < n; i++)
    {
        cin >> x;
        sum[i] = x + sum[i - 1];
        m[sum[i]]++;
    }
    for (ll i = 0; i < n; i++)
    {
        val = sum[i];
        res += m[val - k];
    }
    cout << res;
    return 0;
}