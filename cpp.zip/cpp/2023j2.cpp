#include <iostream>
#include <cstring>
#define ll long long
using namespace std;
struct Node
{
    ll l, r;
} a[110];
char s[110];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    ll n, m;
    cin >> n >> m;
    ll last = 1;
    for (ll i = 1; i <= n; i++)
    {
        cin >> s + 1;
        ll l = 1, r = m;
        while (r >= 1 && s[r] != '1')
        {
            r--;
        }
        while (l <= m && s[l] != '1')
        {
            l++;
        }
        a[i] = {l, r};
        if (l != m + 1)
        {
            last = i;
        }
    }
    ll ans = last - 1, pos = 1;
    for (ll i = 1; i <= n; i++)
    {
        if (a[i].l == m + 1)
        {
            continue;
        }
        if (i & 1)
        {
            if (pos > a[i].l)
            {
                ans += pos - a[i].l;
                pos = a[i].l;
            }
            ans += abs(a[i].r - pos);
            pos = a[i].r;
        }
        else
        {
            if (pos < a[i].r)
            {
                ans += a[i].r - pos;
                pos = a[i].r;
            }
            ans += abs(a[i].l - pos);
            pos = a[i].l;
        }
    }
    cout << ans << '\n';
    return 0;
}