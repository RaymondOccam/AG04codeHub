#include <iostream>
#include <vector>
#include <queue>
#define ll long long
using namespace std;
class Solution
{
public:
    vector<vector<ll>> adj;
    vector<bool> visited;
    vector<vector<ll>> ans;
    void dfs(ll node)
    {
        visited[node] = true;
        vector<ll> path;
        path.push_back(node);
        for (ll neighbor : adj[node])
        {
            if (!visited[neighbor])
            {
                dfs(neighbor);
                path.push_back(neighbor);
            }
        }
        ans.push_back(path);
    }
    vector<vector<ll>> allPathsSourceTarget(vector<vector<ll>> &graph)
    {
        adj = graph;
        ll n = adj.size();
        visited = vector<bool>(n, false);
        dfs(0);
        return ans;
    }
};
int main()
{

    return 0;
}