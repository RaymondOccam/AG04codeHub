#include <bits/stdc++.h>
#define ll long long
using namespace std;
string make0(ll cnt)
{
    string res = "1";
    while (cnt--)
    {
        res.push_back('0');
    }
    return res;
}
string pls(string a, string b)
{
    string ans;
    ll carry = 0;
    ll sum;
    ll len;
    ll lena = a.size();
    ll lenb = b.size();
    ans.clear();
    len = max(a.size(), b.size());
    reverse(a.begin(), a.end());
    reverse(b.begin(), b.end());
    for (ll i = 0; i < len; i++)
    {
        sum = carry;
        if (i < lena)
        {
            sum += a[i] - '0';
        }
        if (i < lenb)
        {
            sum += b[i] - '0';
        }
        ans += sum % 10 + '0';
        carry = sum / 10;
    }
    if (carry)
    {
        ans += '1';
    }
    while (ans.back() == '0' && ans.size() > 1)
    {
        ans.pop_back();
    }
    reverse(ans.begin(), ans.end());
    return ans;
}
int main()
{
    ll a;
    ll b;
    cin >> a >> b;
    string ans = pls(make0(a), to_string(b));
    cout << ans;
    return 0;
}