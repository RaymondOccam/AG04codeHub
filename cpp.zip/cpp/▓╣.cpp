#include <iostream>
#include <cmath>
#define ll long long
#define MAXN 100010
using namespace std;
ll n, m;
ll p[MAXN];
ll a[MAXN], b[MAXN], c[MAXN];
ll res[MAXN];
ll ans;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> m;
    for (ll i = 0; i < m; i++)
    {
        cin >> p[i];
    }
    for (ll i = 0; i < n - 1; i++)
    {
        cin >> a[i] >> b[i] >> c[i];
    }
    for (ll i = 0; i < m - 1; i++)
    {
        if (p[i] < p[i + 1])
        {
            res[p[i] - 1]++, res[p[i + 1] - 1]--;
        }
        else
        {
            res[p[i] - 1]--, res[p[i + 1] - 1]++;
        }
    }
    for (ll i = 1; i < n - 1; i++)
    {
        res[i] += res[i - 1];
    }
    for (ll i = 0; i < n; i++)
    {
        ans += min(a[i] * res[i], c[i] + res[i] * b[i]);
    }
    cout << ans;
    return 0;
}