#include <iostream>
#include <string>
#define ll long long
using namespace std;
string s;
ll res;
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> s;
    for (ll i = 0; i < s.size(); i++)
    {
        if (res == 0 && s[i] == 'h')
        {
            res++;
            continue;
        }
        else if (res == 1 && s[i] == 'e')
        {
            res++;
            continue;
        }
        else if ((res == 2 || res == 3) && s[i] == 'l')
        {
            res++;
            continue;
        }
        else if (res == 4 && s[i] == 'o')
        {
            res++;
            continue;
        }
        else if (res == 5)
        {
            cout << "YES";
            return 0;
        }
    }
    if (res == 5)
    {
        cout << "YES";
    }
    else
    {
        cout << "NO";
    }
    return 0;
}