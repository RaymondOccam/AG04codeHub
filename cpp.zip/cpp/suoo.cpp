#include <iostream>
#define ll long long
using namespace std;
ll n, m, p, x, y, fa[5005], h[5005];
void beg()
{
	for (ll i = 0; i < n; i++)
	{
		fa[i] = i;
	}
}
ll dddddfs(ll x)
{
	if (fa[x] == x)
	{
		return x;
	}
	return fa[x] = dddddfs(fa[x]);
}
void merge(ll x, ll y)
{
	ll xx = dddddfs(x), yy = dddddfs(y);
	fa[xx] = yy;
}
int main()
{
	cin >> n >> m >> p;
	beg();
	for (ll i = 0; i < m; i++)
	{
		cin >> x >> y;
		merge(x, y);
	}
	for (ll i = 0; i < p; i++)
	{
		cin >> x >> y;
		ll xx = dddddfs(x), yy = dddddfs(y);
		if (xx == yy)
		{
			cout << "Yes" << endl;
		}
		else
		{
			cout << "No" << endl;
		}
	}
	return 0;
}