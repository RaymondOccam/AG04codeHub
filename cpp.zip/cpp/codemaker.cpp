#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll a[10000][10000];
ll row_sum[10000];
ll col_sum[10000];
int main()
{
    ll n;
    cin >> n;
    for (ll i = 0; i < n; i++)
    {
        for (ll j = 0; j < n; j++)
        {
            cin >> a[i][j];
            row_sum[i] += a[i][j];
            col_sum[j] += a[i][j];
        }
    }
    ll sum = row_sum[0];
    for (ll i = 1; i < n; i++)
    {
        if (row_sum[i] != sum || col_sum[i] != sum)
        {
            cout << "NO" << endl;
            return 0;
        }
    }
    cout << "YES" << endl;
    return 0;
}