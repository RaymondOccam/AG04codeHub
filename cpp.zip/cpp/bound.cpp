#include <iostream>
#include <algorithm>
#define ll long long
#define MAXN 200050
using namespace std;
ll n, k = 1, l = 1, r = 1, c, res;
ll a[MAXN];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n >> c;
    for (ll i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    sort(a + 1, a + n + 1);
    for (l = 1, k = 1, r = 1; l <= n; l++)
    {
        while (a[r] - a[l] <= c && r <= n)
        {
            r++;
        }
        while (a[k] - a[l] < c && k <= n)
        {
            k++;
        }
        if (a[r - 1] - a[l] == c && a[k] - a[l] == c && r - 1 >= 1)
        {
            res += r - k;
        }
    }
    cout << res;
    return 0;
}