#include <bits/stdc++.h>
#define ll long long
using namespace std;
struct Node
{
    ll a, b;
    friend bool operator<(Node a, Node b)
    {
        return a.a < b.a;
    }
} k[2];
int main()
{
    k[0].a = 1;
    k[0].b = 2;
    k[1].a = 10;
    k[1].b = 5;
    sort(k, k + 2);
    cout << k[0].b;
    return 0;
}