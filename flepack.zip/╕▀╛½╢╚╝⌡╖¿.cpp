#include <bits/stdc++.h>
#define ll long long
using namespace std;
string mns(string a, string b)
{
    string ans;
    ll mit;
    ll len;
    bool sign = false;
    ans.clear();
    if (a.size() < b.size() || (a.size() == b.size() && a < b))
    {
        sign = true;
        swap(a, b);
    }
    reverse(a.begin(), a.end());
    reverse(b.begin(), b.end());
    len = a.size();
    for (ll i = 0; i < len; i++)
    {
        mit = a[i] - '0';
        if (i < b.size())
        {
            mit -= b[i] - '0';
        }
        if (mit < 0)
        {
            mit += 10;
            a[i + 1] -= '1';
        }
        ans += mit % 10 + '0';
    }
    while (ans.back() == '0' && ans.size() > 1)
    {
        ans.pop_back();
    }
    if (sign == true)
    {
        ans += '-';
    }
    reverse(ans.begin(), ans.end());
    return ans;
}
int main()
{
    string m, n;
    cin >> m >> n;
    cout << mns(m, n);
    return 0;
}