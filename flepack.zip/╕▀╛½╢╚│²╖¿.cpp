#include <bits/stdc++.h>
#define ll long long
using namespace std;
string dvt(string a, ll b, ll &r)
{
    string ans;
    ll d = 0;
    ll len = a.size();
    ans.clear();
    for (ll i = 0; i < len; i++)
    {
        d = d * 10 + a[i] - '0';
        ans += d / b % 10 + '0';
        d %= b;
    }
    r = d;
    ll index = 0;
    while (ans[0] == '0' && index < len - 1)
    {
        index++;
    }
    ans = ans.substr(index, len - index);
    return ans;
}
int main()
{
    string m;
    ll n;
    ll r;
    cin >> m >> n;
    cout << dvt(m, n, r) << "......";
    cout << r;
    return 0;
}