#include <bits/stdc++.h>
#define ll long long
using namespace std;
string tms(string a, string b)
{
    ll sum;
    string ans(a.size() + b.size(), '0');
    ll m;
    ll n;
    ll carry = 0;
    reverse(a.begin(), a.end());
    reverse(b.begin(), b.end());
    for (ll i = 0; i < a.size(); i++)
    {
        m = a[i] - '0';
        carry = 0;
        for (ll j = 0; j < b.size(); j++)
        {
            n = b[i] - '0';
            sum = m * n + carry + ans[i + j] - '0';
            ans += sum % 10;
            carry = sum / 10;
        }
        if (carry)
        {
            ans[i + b.size()] += carry;
        }
    }
    while (ans.back() == '0' && ans.size() > 1)
    {
        ans.pop_back();
    }
    reverse(ans.begin(), ans.end());
    return ans;
}
int main()
{
    string o, p;
    cin >> o >> p;
    cout << tms(o, p);
    return 0;
}